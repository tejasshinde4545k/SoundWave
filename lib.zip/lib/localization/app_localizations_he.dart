// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hebrew (`he`).
class AppLocalizationsHe extends AppLocalizations {
  AppLocalizationsHe([String locale = 'he']) : super(locale);

  @override
  String get about => 'אודות האפליקציה';

  @override
  String get accentChangeMsg => 'צבע ההדגשה עודכן בהצלחה';

  @override
  String get accentColor => 'צבע הדגשה';

  @override
  String get add => 'הוסף';

  @override
  String get addPlaylist => 'הוסף פלייליסט';

  @override
  String get addToLikedPlaylists => 'הוסף לפלייליסטים שאהבתי';

  @override
  String get addToLikedSongs => 'הוסף לשירים שאהבתי';

  @override
  String get addToPlaylist => 'הוסף לפלייליסט';

  @override
  String get addToQueue => 'הוסף לתור';

  @override
  String get addedPlaylists => 'פלייליסטים שנוספו';

  @override
  String get addedSuccess => 'נוסף בהצלחה';

  @override
  String get addedToLikedSongs => 'נוסף לשירים שאהבתי';

  @override
  String get album => 'אלבום';

  @override
  String get albums => 'אלבומים';

  @override
  String get allSongs => 'All songs';

  @override
  String get alreadyDownloading => 'כבר מתבצעת הורדה';

  @override
  String get annualRecap => 'סיכום שנתי';

  @override
  String get appUpdateIsAvailable => 'עדכון אפליקציה זמין';

  @override
  String get artist => 'אמן';

  @override
  String get artistNotFound => 'Artist not found. Check logs or try again.';

  @override
  String get artists => 'אמנים';

  @override
  String get audioQuality => 'איכות שמע';

  @override
  String get audioQualityBadge => 'Show audio quality badge';

  @override
  String get audioQualityBadgeDescription =>
      'Display a small bitrate/codec badge on the now playing artwork.';

  @override
  String get audioQualityHigh => 'גבוהה';

  @override
  String get audioQualityLow => 'נמוכה';

  @override
  String get audioQualityMedium => 'בינונית';

  @override
  String get audioQualityMsg => 'איכות השמע עודכנה';

  @override
  String get automaticSongPicker => 'בחירת שירים אוטומטית';

  @override
  String get automaticSongPickerDescription =>
      'הפעל אוטומטית שיר אקראי לאחר סיום השיר הנוכחי.';

  @override
  String get automaticUpdateChecks => 'בדיקת עדכונים אוטומטית';

  @override
  String get automaticUpdateChecksDescription =>
      'בדוק עדכוני אפליקציה באופן אוטומטי בעת ההפעלה.';

  @override
  String get back => 'חזור';

  @override
  String get backToFavorites => 'חזור למועדפים';

  @override
  String get backedupSuccess => 'הנתונים גובו בהצלחה';

  @override
  String get backupError => 'אירעה שגיאה בעת גיבוי הנתונים';

  @override
  String get backupUserData => 'גבה נתוני משתמש';

  @override
  String get becomeSponsor => 'הפוך לתומך';

  @override
  String get cacheMsg => 'המטמון נוקה';

  @override
  String get cancel => 'ביטול';

  @override
  String get cancellingDownload => 'מבטל הורדה...';

  @override
  String get checkForUpdates => 'לבדוק עדכונים?';

  @override
  String get chooseBackupDir => 'בחר תיקיית גיבוי';

  @override
  String get chooseBackupFiles => 'בחר קבצים לגיבוי';

  @override
  String get clear => 'נקה';

  @override
  String get clearCache => 'נקה מטמון';

  @override
  String get clearListeningStats => 'נקה נתוני האזנה';

  @override
  String get clearListeningStatsQuestion =>
      'פעולה זו תמחק את נתוני ההאזנה של Time Machine השמורים במכשיר זה. להמשיך?';

  @override
  String get clearQueue => 'נקה תור';

  @override
  String get clearQueueQuestion => 'האם אתה בטוח שברצונך לנקות את התור?';

  @override
  String get clearRecentlyPlayed => 'נקה היסטוריית השמעה אחרונה';

  @override
  String get clearRecentlyPlayedQuestion =>
      'האם אתה בטוח שברצונך למחוק את היסטוריית ההשמעה האחרונה?';

  @override
  String get clearSearchHistory => 'נקה היסטוריית חיפוש';

  @override
  String get clearSearchHistoryQuestion =>
      'האם אתה בטוח שברצונך למחוק את היסטוריית החיפוש?';

  @override
  String get copy => 'Copy';

  @override
  String get confirm => 'אישור';

  @override
  String get confirmation => 'אישור';

  @override
  String get copyLogs => 'העתק יומנים';

  @override
  String get copyLogsNoLogs => 'אין יומנים להעתקה';

  @override
  String get copyLogsSuccess => 'היומנים הועתקו בהצלחה';

  @override
  String get create => 'צור';

  @override
  String get createFolder => 'צור תיקייה';

  @override
  String get custom => 'מותאם אישית';

  @override
  String get customPlaylistImgUrl => 'כתובת תמונה מותאמת אישית לפלייליסט';

  @override
  String get customPlaylistName => 'שם פלייליסט מותאם אישית';

  @override
  String get customPlaylists => 'פלייליסטים מותאמים אישית';

  @override
  String get dateAdded => 'תאריך הוספה';

  @override
  String get default_ => 'ברירת מחדל';

  @override
  String get delete => 'מחק';

  @override
  String get deleteDownloads => 'מחק הורדות';

  @override
  String get deleteDownloadsQuestion =>
      'האם אתה בטוח שברצונך למחוק את כל ההורדות?';

  @override
  String get deleteFolder => 'מחק תיקייה';

  @override
  String get deleteFolderQuestion =>
      'האם אתה בטוח שברצונך למחוק תיקייה זו? הפלייליסטים שבתוכה יועברו לספרייה הראשית.';

  @override
  String get deletePlaylist => 'מחק פלייליסט';

  @override
  String get download => 'הורד';

  @override
  String get downloadAppUpdate => 'הורד עדכון אפליקציה';

  @override
  String get downloadCancelled => 'ההורדה בוטלה';

  @override
  String get downloadFailed => 'ההורדה נכשלה';

  @override
  String get downloadPlaylist => 'הורד פלייליסט';

  @override
  String get downloadsDeleted => 'ההורדות נמחקו בהצלחה';

  @override
  String get dynamicColor => 'צבע הדגשה דינמי (Android 12+)';

  @override
  String get dynamicColorDescription =>
      'Use the accent colors from your Android system theme.';

  @override
  String get editFolder => 'ערוך תיקייה';

  @override
  String get editPlaylist => 'ערוך פלייליסט';

  @override
  String get emptyFolderMsg =>
      'תיקייה זו ריקה. הוסף פלייליסטים כדי לארגן את המוזיקה שלך.';

  @override
  String get enableUpdateChecksDescription =>
      'האם תרצה ש-SoundWave תבדוק עדכונים אוטומטית מגרסאות GitHub? תמיד ניתן לבדוק עדכונים באופן ידני דרך ההגדרות.';

  @override
  String get endOfSong => 'סוף השיר';

  @override
  String get enterFolderName => 'הזן שם תיקייה';

  @override
  String get equalizer => 'אקולייזר';

  @override
  String get equalizerAndroidOnly => 'האקולייזר זמין רק באנדרואיד.';

  @override
  String get equalizerBands => 'רצועות';

  @override
  String get equalizerDisabledHint => 'שינויי הגבר הרצועות מושבתים.';

  @override
  String get equalizerEnable => 'הפעל אקולייזר';

  @override
  String get equalizerEnabledHint => 'שינויי הגבר הרצועות פעילים.';

  @override
  String get equalizerInitFailed =>
      'לא ניתן לאתחל את האקולייזר כעת. נסה להפעיל שיר ולפתוח מחדש את הדף.';

  @override
  String get equalizerPresetBalanced => 'מאוזן';

  @override
  String get equalizerPresetBassBoost => 'הגברת בס';

  @override
  String get equalizerPresetElectronic => 'אלקטרוני';

  @override
  String get equalizerPresetPop => 'פופ';

  @override
  String get equalizerPresetRock => 'רוק';

  @override
  String get equalizerPresetTrebleBoost => 'הגברת צלילים גבוהים';

  @override
  String get equalizerPresetVocal => 'קולי';

  @override
  String get equalizerPresets => 'הגדרות קבועות מראש';

  @override
  String get equalizerResetBands => 'אפס רצועות';

  @override
  String get error => 'אירעה שגיאה. בדוק את היומנים או נסה שוב.';

  @override
  String get externalRecommendations => 'המלצות חיצוניות';

  @override
  String get externalRecommendationsDescription =>
      'השתמש באלגוריתם חיצוני להמלצות במקום באלגוריתם של SoundWave.';

  @override
  String get failedPlayingRadio => 'הפעלת תחנת הרדיו נכשלה';

  @override
  String get failedToLoadPlaylist => 'טעינת הפלייליסט נכשלה';

  @override
  String get fieldsNotEmpty => 'יש למלא את כל השדות';

  @override
  String get folderAlreadyExists => 'תיקייה בשם זה כבר קיימת';

  @override
  String get folderDeleted => 'התיקייה נמחקה בהצלחה';

  @override
  String get folderName => 'שם התיקייה';

  @override
  String get folderUpdated => 'התיקייה עודכנה בהצלחה';

  @override
  String get goToArtist => 'עבור לאמן';

  @override
  String get home => 'בית';

  @override
  String get hours => 'שעות';

  @override
  String get imagePicked => 'התמונה נבחרה';

  @override
  String get importSpotifyPlaylist => 'Import playlist from Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Import Spotify playlist';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Export your Spotify playlist as CSV at chosic.com/spotify-playlist-exporter/, then choose the file or paste its contents below. SoundWave will search YouTube for each song.';

  @override
  String get chooseCsvFile => 'Choose CSV file';

  @override
  String get openChosicExporter => 'Open Chosic Spotify exporter';

  @override
  String get pasteCsv => 'Paste CSV';

  @override
  String get playlistName => 'Playlist name';

  @override
  String get importPlaylist => 'Import playlist';

  @override
  String get spotifyCsvHint => 'Paste CSV content here';

  @override
  String get spotifyPlaylistNameHint => 'Imported Spotify playlist';

  @override
  String get spotifyPlaylistEmpty =>
      'Choose a CSV file or paste CSV content first';

  @override
  String get enterPlaylistName => 'Please enter a playlist name';

  @override
  String get spotifyPlaylistInvalid =>
      'The CSV does not contain Song and Artist columns';

  @override
  String get spotifyPlaylistImporting => 'Importing playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found of $total songs imported';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Searching $done of $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'An import is already in progress';

  @override
  String get spotifyPlaylistMissingSongs => 'Songs not found';

  @override
  String get spotifyPlaylistImportFailed => 'Playlist import failed';

  @override
  String get invalidYouTubePlaylist => 'פלייליסט YouTube לא חוקי';

  @override
  String get language => 'שפה';

  @override
  String get languageDe => 'גרמנית';

  @override
  String get languageEl => 'יוונית';

  @override
  String get languageEn => 'אנגלית';

  @override
  String get languageEs => 'ספרדית';

  @override
  String get languageEt => 'אסטונית';

  @override
  String get languageFr => 'צרפתית';

  @override
  String get languageHe => 'עברית';

  @override
  String get languageHi => 'הינדי';

  @override
  String get languageHu => 'הונגרית';

  @override
  String get languageId => 'אינדונזית';

  @override
  String get languageIt => 'איטלקית';

  @override
  String get languageJa => 'יפנית';

  @override
  String get languageKo => 'קוריאנית';

  @override
  String get languageMsg => 'השפה עודכנה בהצלחה';

  @override
  String get languagePl => 'פולנית';

  @override
  String get languagePt => 'פורטוגזית';

  @override
  String get languageRu => 'רוסית';

  @override
  String get languageSv => 'שוודית';

  @override
  String get languageTa => 'טמילית';

  @override
  String get languageTr => 'טורקית';

  @override
  String get languageUk => 'אוקראינית';

  @override
  String get languageZh => 'סינית (מפושטת)';

  @override
  String get languageZhHant => 'סינית (מסורתית)';

  @override
  String get library => 'ספרייה';

  @override
  String get licenses => 'רישיונות';

  @override
  String get likedPlaylists => 'פלייליסטים שאהבתי';

  @override
  String get likedSongs => 'שירים שאהבתי';

  @override
  String get linkCopied => 'קישור הפלייליסט הועתק ללוח';

  @override
  String get listeningStats => 'נתוני האזנה';

  @override
  String get listeningStatsCleared => 'נתוני ההאזנה נוקו';

  @override
  String get listeningStatsDescription =>
      'עקוב אחר נתוני האזנה מקומיים לסיכומים חודשיים ושנתיים.';

  @override
  String get loading => 'טוען';

  @override
  String get lyrics => 'מילים';

  @override
  String get lyricsNotAvailable => 'המילים אינן זמינות';

  @override
  String get makeOffline => 'הפוך לזמין במצב לא מקוון';

  @override
  String get minutes => 'דקות';

  @override
  String get minutesListened => 'דקות האזנה';

  @override
  String get monthlyListeners => 'monthly listeners';

  @override
  String get moreOptions => 'אפשרויות נוספות';

  @override
  String get mostPlayed => 'המושמעים ביותר';

  @override
  String get moveToFolder => 'העבר לתיקייה';

  @override
  String get name => 'שם';

  @override
  String get newAnnouncement => 'הודעה חדשה פורסמה';

  @override
  String get newFolder => 'תיקייה חדשה';

  @override
  String get no => 'לא';

  @override
  String get noCustomPlaylists => 'עדיין לא נוצרו פלייליסטים מותאמים אישית';

  @override
  String get noFolders => 'עדיין לא נוצרו תיקיות';

  @override
  String get noListeningStats => 'אין עדיין נתוני האזנה';

  @override
  String get noOfflineLibraryContent =>
      'אין תוכן לא מקוון. הפעל מצב מקוון או הורד פלייליסטים/שירים כדי להשתמש בספרייה.';

  @override
  String get noPlaylistsAdded => 'עדיין לא נוספו פלייליסטים';

  @override
  String get noRadioStations => 'אין תחנות רדיו זמינות';

  @override
  String get noSongsInPlaylist => 'אין שירים בפלייליסט';

  @override
  String get noSongsInQueue => 'אין שירים בתור';

  @override
  String get notYTlist => 'מזהה פלייליסט YouTube לא חוקי';

  @override
  String get offlineMode => 'מצב לא מקוון';

  @override
  String get offlineModeDescription =>
      'השבת תכונות מקוונות והשתמש ב-SoundWave באופן מלא במצב לא מקוון.';

  @override
  String get offlinePlaylists => 'פלייליסטים לא מקוונים';

  @override
  String get offlineSongs => 'שירים לא מקוונים';

  @override
  String get others => 'אחרים';

  @override
  String get pause => 'השהה';

  @override
  String get pickImageFromDevice => 'בחר תמונה מהמכשיר';

  @override
  String get pinToLibrary => 'הצמד לספרייה';

  @override
  String get pinnedPlaylists => 'מוצמדים';

  @override
  String get pinnedPlaylistsLimit => 'ניתן להצמיד עד 5 פלייליסטים או אלבומים';

  @override
  String get play => 'נגן';

  @override
  String get playNext => 'נגן הבא';

  @override
  String get playlist => 'פלייליסט';

  @override
  String get playlistAlreadyDownloaded => 'הפלייליסט כבר הורד';

  @override
  String get playlistAlreadyExists => 'הפלייליסט כבר קיים';

  @override
  String get playlistDownloaded => 'הפלייליסט הורד';

  @override
  String get playlistEmpty => 'הפלייליסט ריק';

  @override
  String get playlistFolders => 'תיקיות פלייליסטים';

  @override
  String get playlistRemovedFromOffline => 'הפלייליסט הוסר מהמצב הלא מקוון';

  @override
  String get playlistUpdated => 'הפלייליסט עודכן בהצלחה';

  @override
  String get playlists => 'פלייליסטים';

  @override
  String get preferences => 'העדפות';

  @override
  String get provideIdOrNameError =>
      'אנא הזן מזהה YouTube או שם פלייליסט מותאם אישית';

  @override
  String get pureBlackTheme => 'ערכת נושא שחורה מלאה';

  @override
  String get pureBlackThemeDescription =>
      'Use a true black background in dark mode for OLED displays.';

  @override
  String get queue => 'תור';

  @override
  String get radioStations => 'תחנות רדיו';

  @override
  String get recentlyPlayed => 'נוגן לאחרונה';

  @override
  String get recentlyPlayedMsg => 'היסטוריית ההשמעה האחרונה נוקתה';

  @override
  String get recommendedForYou => 'מומלץ עבורך';

  @override
  String get remove => 'הסר';

  @override
  String get removeFromFolder => 'הסר מהתיקייה';

  @override
  String get removeFromLikedPlaylists => 'הסר מפלייליסטים שאהבתי';

  @override
  String get removeFromLikedSongs => 'הסר משירים שאהבתי';

  @override
  String get removeFromPlaylist => 'הסר מהפלייליסט';

  @override
  String get removeFromRecentlyPlayed => 'הסר מהנוגנו לאחרונה';

  @override
  String get removeOffline => 'הסר ממצב לא מקוון';

  @override
  String get removeOfflinePlaylist => 'הסר פלייליסט לא מקוון';

  @override
  String get removeOfflinePlaylistConfirm =>
      'פעולה זו תסיר את הפלייליסט מהמצב הלא מקוון. שירים המשמשים בפלייליסטים אחרים יישארו זמינים.';

  @override
  String get removePlaylistQuestion =>
      'האם אתה בטוח שברצונך להסיר את הפלייליסט הזה?';

  @override
  String get removeSearchQueryQuestion =>
      'האם אתה בטוח שברצונך להסיר את שאילתת החיפוש הזו?';

  @override
  String get removedFromLikedSongs => 'הוסר משירים שאהבתי';

  @override
  String get renameSong => 'שנה שם שיר';

  @override
  String get repeat => 'חזרה';

  @override
  String get replay => 'נגן שוב';

  @override
  String get restoreError => 'אירעה שגיאה בעת שחזור הנתונים';

  @override
  String get restoreUserData => 'שחזר נתוני משתמש';

  @override
  String get restoredSuccess => 'הנתונים שוחזרו בהצלחה';

  @override
  String get search => 'חיפוש';

  @override
  String get searchHistoryMsg => 'היסטוריית החיפוש נוקתה';

  @override
  String get selectDuration => 'בחר משך זמן';

  @override
  String get setTimer => 'הגדר טיימר';

  @override
  String get settingChangedMsg => 'ההגדרות עודכנו בהצלחה';

  @override
  String get settings => 'הגדרות';

  @override
  String get share => 'שתף';

  @override
  String get shareRecap => 'שתף סיכום';

  @override
  String get shareTimeMachineText => 'סיכום SoundWave שלי';

  @override
  String get shuffle => 'ערבוב';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Singles & EPs';

  @override
  String get skipToNext => 'דלג לבא';

  @override
  String get skipToPrevious => 'דלג לקודם';

  @override
  String get sleepTimer => 'טיימר שינה';

  @override
  String get sleepTimerCancelled => 'טיימר השינה בוטל';

  @override
  String get sleepTimerSet => 'טיימר השינה הוגדר';

  @override
  String get songAdded => 'השיר נוסף';

  @override
  String get songAddedToOffline => 'השיר זמין כעת במצב לא מקוון';

  @override
  String get songAlreadyInPlaylist => 'השיר כבר נמצא בפלייליסט';

  @override
  String get songRemoved => 'השיר הוסר';

  @override
  String get songRemovedFromOffline => 'השיר אינו זמין יותר במצב לא מקוון';

  @override
  String get songs => 'שירים';

  @override
  String get sponsorBlockDescription => 'דלג על קטעים ממומנים בשירים נתמכים.';

  @override
  String get sponsorProject => 'תמוך בפרויקט';

  @override
  String get suggestedArtists => 'אמנים מומלצים';

  @override
  String get suggestedPlaylists => 'פלייליסטים מומלצים';

  @override
  String get tapToView => 'הקש לצפייה';

  @override
  String get themeMode => 'מצב ערכת נושא';

  @override
  String get themeModeDark => 'כהה';

  @override
  String get themeModeLight => 'בהיר';

  @override
  String get themeModeSystem => 'מערכת';

  @override
  String get timeMachine => 'מכונת זמן';

  @override
  String get tools => 'כלים';

  @override
  String get topSongs => 'Top songs';

  @override
  String get translate => 'תרגם';

  @override
  String get translateDescription =>
      'עזור לתרגם את SoundWave לשפה שלך ב-Crowdin.';

  @override
  String get understand => 'הבנתי';

  @override
  String get undo => 'בטל';

  @override
  String get unpinFromLibrary => 'בטל הצמדה מהספרייה';

  @override
  String get update => 'עדכן';

  @override
  String get useProxy => 'השתמש בפרוקסי';

  @override
  String get useProxyDescription =>
      'השתמש בפרוקסי רק כאשר ההזרמה נכשלת. שימוש מיותר עלול לפגוע בהפעלה.';

  @override
  String get userPlaylists => 'פלייליסטים של משתמש';

  @override
  String get yes => 'כן';

  @override
  String get youtubePlaylistLinkOrId => 'קישור או מזהה של פלייליסט YouTube';
}
