// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Italian (`it`).
class AppLocalizationsIt extends AppLocalizations {
  AppLocalizationsIt([String locale = 'it']) : super(locale);

  @override
  String get about => 'Info';

  @override
  String get accentChangeMsg => 'Colore principale cambiato con successo';

  @override
  String get accentColor => 'Colore principale';

  @override
  String get add => 'Aggiungi';

  @override
  String get addPlaylist => 'Aggiungi playlist';

  @override
  String get addToLikedPlaylists => 'Aggiungi alle playlist preferite';

  @override
  String get addToLikedSongs => 'Aggiungi ai brani preferiti';

  @override
  String get addToPlaylist => 'Aggiungi alla playlist';

  @override
  String get addToQueue => 'Aggiungi in coda';

  @override
  String get addedPlaylists => 'Scalette aggiunte';

  @override
  String get addedSuccess => 'Aggiunto con successo';

  @override
  String get addedToLikedSongs => 'Aggiunto a brani che ti piacciono';

  @override
  String get album => 'Album';

  @override
  String get albums => 'Albums';

  @override
  String get allSongs => 'Tutte le canzoni';

  @override
  String get alreadyDownloading => 'Già in download';

  @override
  String get annualRecap => 'Ricapitalizzazione annuale';

  @override
  String get appUpdateIsAvailable => 'Aggiornamento app disponibile';

  @override
  String get artist => 'Artista';

  @override
  String get artistNotFound =>
      'Artista non trovato. Controlla i log o riprova.';

  @override
  String get artists => 'Artisti';

  @override
  String get audioQuality => 'Qualità audio';

  @override
  String get audioQualityBadge => 'Mostra distintivo di qualità di audio';

  @override
  String get audioQualityBadgeDescription =>
      'Mostra un piccolo badge bitrate/codec sull\'arte che sta giocando.';

  @override
  String get audioQualityHigh => 'Alta';

  @override
  String get audioQualityLow => 'Bassa';

  @override
  String get audioQualityMedium => 'Media';

  @override
  String get audioQualityMsg => 'Qualità audio cambiata con successo';

  @override
  String get automaticSongPicker => 'Suggerimento automatico brani';

  @override
  String get automaticSongPickerDescription =>
      'Riproduci automaticamente un brano casuale al termine della traccia corrente.';

  @override
  String get automaticUpdateChecks => 'Controlli automatici di aggiornamento';

  @override
  String get automaticUpdateChecksDescription =>
      'Controlla automaticamente la presenza di aggiornamenti delle app all\'avvio.';

  @override
  String get back => 'Indietro';

  @override
  String get backToFavorites => 'Torna ai preferiti';

  @override
  String get backedupSuccess => 'Dati salvati con successo';

  @override
  String get backupError => 'Errore durante il salvataggio dei dati';

  @override
  String get backupUserData => 'Backup dati utente';

  @override
  String get becomeSponsor => 'Diventa uno sponsor';

  @override
  String get cacheMsg => 'Cache pulita con successo';

  @override
  String get cancel => 'Annulla';

  @override
  String get cancellingDownload => 'Annullamento scaricamento...';

  @override
  String get checkForUpdates => 'Controlla aggiornamenti?';

  @override
  String get chooseBackupDir => 'Scegli directory di backup';

  @override
  String get chooseBackupFiles => 'Scegli file di backup';

  @override
  String get clear => 'Pulisci';

  @override
  String get clearCache => 'Pulisci cache';

  @override
  String get clearListeningStats => 'Cancella statistiche di ascolto';

  @override
  String get clearListeningStatsQuestion =>
      'Questo eliminerà le statistiche di ascolto Time Machine memorizzate su questo dispositivo. Continuare?';

  @override
  String get clearQueue => 'Elimina coda';

  @override
  String get clearQueueQuestion => 'Sei sicuro di voler svuotare la coda?';

  @override
  String get clearRecentlyPlayed => 'Cancella cronologia recenti';

  @override
  String get clearRecentlyPlayedQuestion => 'Cancellare cronologia recenti?';

  @override
  String get clearSearchHistory => 'Cancella cronologia ricerche';

  @override
  String get clearSearchHistoryQuestion => 'Cancellare cronologia ricerche?';

  @override
  String get copy => 'Copia';

  @override
  String get confirm => 'Conferma';

  @override
  String get confirmation => 'Conferma';

  @override
  String get copyLogs => 'Copia log';

  @override
  String get copyLogsNoLogs => 'Nessun log trovato da copiare';

  @override
  String get copyLogsSuccess => 'Log copiati con successo';

  @override
  String get create => 'Crea';

  @override
  String get createFolder => 'Crea cartella';

  @override
  String get custom => 'Personalizza';

  @override
  String get customPlaylistImgUrl => 'Link immagine playlist personalizzata';

  @override
  String get customPlaylistName => 'Nome playlist personalizzata';

  @override
  String get customPlaylists => 'Playlist personalizzate';

  @override
  String get dateAdded => 'Data Aggiunta';

  @override
  String get default_ => 'Predefinito';

  @override
  String get delete => 'Elimina';

  @override
  String get deleteDownloads => 'Elimina download';

  @override
  String get deleteDownloadsQuestion =>
      'Sei sicuro di voler eliminare tutti i download?';

  @override
  String get deleteFolder => 'Elimina cartella';

  @override
  String get deleteFolderQuestion =>
      'Sei sicuro di voler eliminare questa cartella? Le scalette all\'interno saranno spostate nella libreria principale.';

  @override
  String get deletePlaylist => 'Cancella playlist';

  @override
  String get download => 'Scarica';

  @override
  String get downloadAppUpdate => 'Scarica aggiornamento app';

  @override
  String get downloadCancelled => 'Download annullato';

  @override
  String get downloadFailed => 'Download non riuscito';

  @override
  String get downloadPlaylist => 'Scarica playlist';

  @override
  String get downloadsDeleted => 'Download eliminati con successo';

  @override
  String get dynamicColor => 'Colore dinamico (Android 12+)';

  @override
  String get dynamicColorDescription =>
      'Utilizzare i colori accento dal vostro tema di sistema Android.';

  @override
  String get editFolder => 'Modifica cartella';

  @override
  String get editPlaylist => 'Modifica playlist';

  @override
  String get emptyFolderMsg =>
      'Questa cartella è vuota. Aggiungi playlist per organizzare la tua musica.';

  @override
  String get enableUpdateChecksDescription =>
      'Vuoi che SoundWave controlli automaticamente gli aggiornamenti dalle versioni di GitHub? Puoi sempre controllare manualmente gli aggiornamenti dalle impostazioni';

  @override
  String get endOfSong => 'Fine del brano';

  @override
  String get enterFolderName => 'Inserisci un nome per la cartella';

  @override
  String get equalizer => 'Equalizzatore';

  @override
  String get equalizerAndroidOnly =>
      'Equalizzatore disponibile solo su Android.';

  @override
  String get equalizerBands => 'Bande';

  @override
  String get equalizerDisabledHint =>
      'Le regolazioni delle bande sono disattivate.';

  @override
  String get equalizerEnable => 'Abilita equalizzatore';

  @override
  String get equalizerEnabledHint => 'Le regolazioni delle bande sono attive.';

  @override
  String get equalizerInitFailed =>
      'L\'equalizzatore non può essere inizializzato ora. Prova a suonare una canzone e riapri questa pagina.';

  @override
  String get equalizerPresetBalanced => 'Equilibrato';

  @override
  String get equalizerPresetBassBoost => 'Potenziamento dei bassi';

  @override
  String get equalizerPresetElectronic => 'Elettronica';

  @override
  String get equalizerPresetPop => 'Pop';

  @override
  String get equalizerPresetRock => 'Rock';

  @override
  String get equalizerPresetTrebleBoost => 'Esalta gli alti';

  @override
  String get equalizerPresetVocal => 'Voce';

  @override
  String get equalizerPresets => 'Profili';

  @override
  String get equalizerResetBands => 'Reimposta bande';

  @override
  String get error => 'Qualcosa è andato storto';

  @override
  String get externalRecommendations => 'Raccomandazioni esterne';

  @override
  String get externalRecommendationsDescription =>
      'Usa l\'algoritmo esterno per i suggerimenti invece di quello di SoundWave.';

  @override
  String get failedPlayingRadio =>
      'Riproduzione della stazione radio non riuscita';

  @override
  String get failedToLoadPlaylist => 'Errore caricamento playlist';

  @override
  String get fieldsNotEmpty => 'Tutti i campi devono essere riempiti';

  @override
  String get folderAlreadyExists => 'Esiste già una cartella con questo nome';

  @override
  String get folderDeleted => 'Cartella eliminata correttamente';

  @override
  String get folderName => 'Nome cartella';

  @override
  String get folderUpdated => 'Cartella aggiornata con successo';

  @override
  String get goToArtist => 'Vai all\'artista';

  @override
  String get home => 'Home';

  @override
  String get hours => 'Ore';

  @override
  String get imagePicked => 'Immagine selezionata';

  @override
  String get importSpotifyPlaylist => 'Importa playlist da Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Importa playlist di Spotify';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Esporta la tua playlist Spotify come CSV su chosic.com/spotify-playlist-exporter/, quindi scegli il file o incolla il contenuto qui sotto. SoundWave cercherà YouTube per ogni canzone.';

  @override
  String get chooseCsvFile => 'Scegli file CSV';

  @override
  String get openChosicExporter => 'Open Chosic Spotify esportatore';

  @override
  String get pasteCsv => 'Incolla CSV';

  @override
  String get playlistName => 'Titolo playlist';

  @override
  String get importPlaylist => 'Importa playlist';

  @override
  String get spotifyCsvHint => 'Incolla qui il contenuto CSV';

  @override
  String get spotifyPlaylistNameHint => 'Playlist Spotify importata';

  @override
  String get spotifyPlaylistEmpty =>
      'Scegliere prima un file CSV o incollare un contenuto CSV';

  @override
  String get enterPlaylistName => 'Inserisci il nome della playlist';

  @override
  String get spotifyPlaylistInvalid =>
      'Il CSV non contiene colonne di brano e artista';

  @override
  String get spotifyPlaylistImporting => 'Importazione della playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found di $total canzoni importati';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Ricerca di $done di $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'Un\'importazione è già in corso';

  @override
  String get spotifyPlaylistMissingSongs => 'Brani non trovati';

  @override
  String get spotifyPlaylistImportFailed =>
      'Importazione della playlist non riuscita';

  @override
  String get invalidYouTubePlaylist => 'Playlist YouTube non valida';

  @override
  String get language => 'Lingua';

  @override
  String get languageDe => 'Tedesco';

  @override
  String get languageEl => 'Greco';

  @override
  String get languageEn => 'Inglese';

  @override
  String get languageEs => 'Spagnolo';

  @override
  String get languageEt => 'Estone';

  @override
  String get languageFr => 'Francese';

  @override
  String get languageHe => 'Ebraico';

  @override
  String get languageHi => 'Hindi';

  @override
  String get languageHu => 'Ungherese';

  @override
  String get languageId => 'Indonesiano';

  @override
  String get languageIt => 'Italiano';

  @override
  String get languageJa => 'Giapponese';

  @override
  String get languageKo => 'Coreano';

  @override
  String get languageMsg => 'Lingua cambiata con successo';

  @override
  String get languagePl => 'Polacco';

  @override
  String get languagePt => 'Portoghese';

  @override
  String get languageRu => 'Russo';

  @override
  String get languageSv => 'Svedese';

  @override
  String get languageTa => 'Tamil';

  @override
  String get languageTr => 'Turco';

  @override
  String get languageUk => 'Ucraino';

  @override
  String get languageZh => 'Cinese (semplificato)';

  @override
  String get languageZhHant => 'Cinese (tradizionale)';

  @override
  String get library => 'Libreria';

  @override
  String get licenses => 'Licenze';

  @override
  String get likedPlaylists => 'Playlist preferite';

  @override
  String get likedSongs => 'Brani preferiti';

  @override
  String get linkCopied => 'Link della playlist copiato negli appunti';

  @override
  String get listeningStats => 'Statistiche di ascolto';

  @override
  String get listeningStatsCleared => 'Statistiche di ascolto eliminate';

  @override
  String get listeningStatsDescription =>
      'Traccia le statistiche di ascolto locale per ricapitoli mensili e annuali.';

  @override
  String get loading => 'Caricamento';

  @override
  String get lyrics => 'Testi';

  @override
  String get lyricsNotAvailable => 'Testi non disponibili';

  @override
  String get makeOffline => 'Rendi disponibile offline';

  @override
  String get minutes => 'Minuti';

  @override
  String get minutesListened => 'minuti ascoltati';

  @override
  String get monthlyListeners => 'ascoltatori mensili';

  @override
  String get moreOptions => 'Più opzioni';

  @override
  String get mostPlayed => 'Più riprodotti';

  @override
  String get moveToFolder => 'Sposta nella cartella';

  @override
  String get name => 'Nome';

  @override
  String get newAnnouncement => 'Nuovo annuncio pubblicato';

  @override
  String get newFolder => 'Nuova cartella';

  @override
  String get no => 'No';

  @override
  String get noCustomPlaylists =>
      'Non hai ancora creato playlist personalizzate';

  @override
  String get noFolders => 'Nessuna cartella creata ancora';

  @override
  String get noListeningStats => 'Ancora nessuna statistica di ascolto';

  @override
  String get noOfflineLibraryContent =>
      'Nessun contenuto offline. Abilita modalità online oppure scarica playlist/brani per usare la libreria offline.';

  @override
  String get noPlaylistsAdded => 'Nessuna scaletta ancora aggiunta';

  @override
  String get noRadioStations => 'Nessuna stazione radio disponibile';

  @override
  String get noSongsInPlaylist => 'Nessuna canzone nella playlist';

  @override
  String get noSongsInQueue => 'Nessun brano in coda';

  @override
  String get notYTlist => 'Questo non è un ID playlist di YouTube valido';

  @override
  String get offlineMode => 'Modalità offline';

  @override
  String get offlineModeDescription =>
      'Disabilita le funzioni online e utlizza SoundWave completamente offline.';

  @override
  String get offlinePlaylists => 'Scalette offline';

  @override
  String get offlineSongs => 'Brani offline';

  @override
  String get others => 'Altri';

  @override
  String get pause => 'Pausa';

  @override
  String get pickImageFromDevice => 'Scegli immagine dal dispositivo';

  @override
  String get pinToLibrary => 'Aggiungi alla libreria';

  @override
  String get pinnedPlaylists => 'Fissato';

  @override
  String get pinnedPlaylistsLimit =>
      'Puoi aggiungere fino a 5 playlist o album';

  @override
  String get play => 'Riproduci';

  @override
  String get playNext => 'Riproduci successivo';

  @override
  String get playlist => 'Playlist';

  @override
  String get playlistAlreadyDownloaded => 'Playlist già scaricata';

  @override
  String get playlistAlreadyExists => 'Playlist già esistente';

  @override
  String get playlistDownloaded => 'Playlist scaricata';

  @override
  String get playlistEmpty => 'La scaletta è vuota';

  @override
  String get playlistFolders => 'Cartelle playlist';

  @override
  String get playlistRemovedFromOffline =>
      'Playlist rimossa dalla memoria fuori rete';

  @override
  String get playlistUpdated => 'Playlist aggiornata con successo';

  @override
  String get playlists => 'Playlist';

  @override
  String get preferences => 'Preferenze';

  @override
  String get provideIdOrNameError =>
      'Per favore fornisci un ID YouTube o un nome di playlist personalizzata';

  @override
  String get pureBlackTheme => 'Tema nero puro';

  @override
  String get pureBlackThemeDescription =>
      'Utilizzare un vero sfondo nero in modalità scura per i display OLED.';

  @override
  String get queue => 'Coda';

  @override
  String get radioStations => 'Stazioni radio';

  @override
  String get recentlyPlayed => 'Recentemente riprodotti';

  @override
  String get recentlyPlayedMsg => 'Cronologia recenti cancellata';

  @override
  String get recommendedForYou => 'Raccomandato per te';

  @override
  String get remove => 'Rimuovi';

  @override
  String get removeFromFolder => 'Rimuovi dalla cartella';

  @override
  String get removeFromLikedPlaylists =>
      'Rimuovi dalle playlist aggiunte ai preferiti';

  @override
  String get removeFromLikedSongs => 'Rimuovi dai brani aggiunti ai preferiti';

  @override
  String get removeFromPlaylist => 'Rimuovi dalla playlist';

  @override
  String get removeFromRecentlyPlayed => 'Rimuovi da riprodotti di recente';

  @override
  String get removeOffline => 'Rimuovi dai brani disponibili offline';

  @override
  String get removeOfflinePlaylist => 'Rimuovi Scaletta Offline';

  @override
  String get removeOfflinePlaylistConfirm =>
      'Questo rimuoverà la scaletta dalla memoria offline. I brani che vengono utilizzati in altre scalette saranno ancora disponibili.';

  @override
  String get removePlaylistQuestion => 'Rimuovere questa playlist?';

  @override
  String get removeSearchQueryQuestion => 'Rimuovere questa ricerca?';

  @override
  String get removedFromLikedSongs => 'Rimosso da brani che ti piacciono';

  @override
  String get renameSong => 'Rinomina brano';

  @override
  String get repeat => 'Ripeti';

  @override
  String get replay => 'Riascolta';

  @override
  String get restoreError => 'Errore durante il ripristino dei dati';

  @override
  String get restoreUserData => 'Ripristina dati utente';

  @override
  String get restoredSuccess => 'Dati ripristinati con successo';

  @override
  String get search => 'Cerca';

  @override
  String get searchHistoryMsg => 'Cronologia ricerche cancellata';

  @override
  String get selectDuration => 'Seleziona durata';

  @override
  String get setTimer => 'Imposta timer';

  @override
  String get settingChangedMsg => 'Impostazioni cambiate';

  @override
  String get settings => 'Impostazioni';

  @override
  String get share => 'Condividi';

  @override
  String get shareRecap => 'Condividi riepilogo';

  @override
  String get shareTimeMachineText => 'Mi SoundWave riepilogo';

  @override
  String get shuffle => 'Riproduzione casuale';

  @override
  String get single => 'Singolo';

  @override
  String get singlesAndEps => 'Singoli ed EP';

  @override
  String get skipToNext => 'Salta alla successiva';

  @override
  String get skipToPrevious => 'Torna alla precedente';

  @override
  String get sleepTimer => 'Timer di spegnimento';

  @override
  String get sleepTimerCancelled => 'Timer di sospensione annullato';

  @override
  String get sleepTimerSet => 'Timer di spegnimento impostato';

  @override
  String get songAdded => 'Brano aggiunto con successo';

  @override
  String get songAddedToOffline => 'Il brano è ora disponibile offline';

  @override
  String get songAlreadyInPlaylist => 'Il brano è già contenuto nella playlist';

  @override
  String get songRemoved => 'Brano rimosso con successo';

  @override
  String get songRemovedFromOffline => 'Il brano non è più disponibile offline';

  @override
  String get songs => 'Brani';

  @override
  String get sponsorBlockDescription =>
      'Skip sponsored segments in supported tracks.';

  @override
  String get sponsorProject => 'Sosteni il progetto';

  @override
  String get suggestedArtists => 'Artisti suggeriti';

  @override
  String get suggestedPlaylists => 'Playlist suggerite';

  @override
  String get tapToView => 'Premi per vedere';

  @override
  String get themeMode => 'Modalità tema';

  @override
  String get themeModeDark => 'Scuro';

  @override
  String get themeModeLight => 'Chiaro';

  @override
  String get themeModeSystem => 'Sistema';

  @override
  String get timeMachine => 'Time Macchine';

  @override
  String get tools => 'Strumenti';

  @override
  String get topSongs => 'Brani più venduti';

  @override
  String get translate => 'Translate';

  @override
  String get translateDescription =>
      'Help translate SoundWave into your language on Crowdin.';

  @override
  String get understand => 'Capisco';

  @override
  String get undo => 'Annulla';

  @override
  String get unpinFromLibrary => 'Sblocca dalla libreria';

  @override
  String get update => 'Aggiorna';

  @override
  String get useProxy => 'Usa proxy';

  @override
  String get useProxyDescription =>
      'Usa il proxy solo per eventuali errori di streaming, se non necessario potrebbe interrompere la riproduzione.';

  @override
  String get userPlaylists => 'Playlist utente';

  @override
  String get yes => 'Sì';

  @override
  String get youtubePlaylistLinkOrId => 'YouTube playlist link o ID';
}
