// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Estonian (`et`).
class AppLocalizationsEt extends AppLocalizations {
  AppLocalizationsEt([String locale = 'et']) : super(locale);

  @override
  String get about => 'Rakendusest';

  @override
  String get accentChangeMsg => 'Aktsentvärv värskendati edukalt';

  @override
  String get accentColor => 'Aktsentvärv';

  @override
  String get add => 'Lisa';

  @override
  String get addPlaylist => 'Lisa esitusloend';

  @override
  String get addToLikedPlaylists => 'Lisa lemmikesitusloenditesse';

  @override
  String get addToLikedSongs => 'Lisa lemmiklugude hulka';

  @override
  String get addToPlaylist => 'Lisa esitusloendisse';

  @override
  String get addToQueue => 'Lisa järjekorda';

  @override
  String get addedPlaylists => 'Lisatud esitusloendid';

  @override
  String get addedSuccess => 'Edukalt lisatud';

  @override
  String get addedToLikedSongs => 'Lisatud lemmiklugude hulka';

  @override
  String get album => 'Album';

  @override
  String get albums => 'Albumid';

  @override
  String get allSongs => 'All songs';

  @override
  String get alreadyDownloading => 'Juba allalaadimisel';

  @override
  String get annualRecap => 'Aasta kokkuvõte';

  @override
  String get appUpdateIsAvailable => 'Uuendus on saadaval';

  @override
  String get artist => 'Artist';

  @override
  String get artistNotFound => 'Artist not found. Check logs or try again.';

  @override
  String get artists => 'Artistid';

  @override
  String get audioQuality => 'Helikvaliteet';

  @override
  String get audioQualityBadge => 'Show audio quality badge';

  @override
  String get audioQualityBadgeDescription =>
      'Display a small bitrate/codec badge on the now playing artwork.';

  @override
  String get audioQualityHigh => 'Kõrge';

  @override
  String get audioQualityLow => 'Madal';

  @override
  String get audioQualityMedium => 'Keskmine';

  @override
  String get audioQualityMsg => 'Helikvaliteet uuendatud';

  @override
  String get automaticSongPicker => 'Automaatne lugude valik';

  @override
  String get automaticSongPickerDescription =>
      'Esita automaatselt juhuslik lugu pärast praeguse loo lõppu.';

  @override
  String get automaticUpdateChecks => 'Automaatne uuenduste kontroll';

  @override
  String get automaticUpdateChecksDescription =>
      'Kontrolli käivitamisel automaatselt rakenduse uuendusi.';

  @override
  String get back => 'Tagasi';

  @override
  String get backToFavorites => 'Tagasi lemmikute juurde';

  @override
  String get backedupSuccess => 'Andmed edukalt varundatud';

  @override
  String get backupError => 'Andmete varundamisel tekkis viga';

  @override
  String get backupUserData => 'Varunda kasutajaandmed';

  @override
  String get becomeSponsor => 'Hakka sponsoriks';

  @override
  String get cacheMsg => 'Vahemälu tühjendatud';

  @override
  String get cancel => 'Tühista';

  @override
  String get cancellingDownload => 'Allalaadimise tühistamine...';

  @override
  String get checkForUpdates => 'Kontrolli uuendusi?';

  @override
  String get chooseBackupDir => 'Vali varunduskaust';

  @override
  String get chooseBackupFiles => 'Vali varundatavad failid';

  @override
  String get clear => 'Tühjenda';

  @override
  String get clearCache => 'Tühjenda vahemälu';

  @override
  String get clearListeningStats => 'Tühjenda kuulamisstatistika';

  @override
  String get clearListeningStatsQuestion =>
      'See kustutab selles seadmes salvestatud Time Machine kuulamisstatistika. Kas jätkata?';

  @override
  String get clearQueue => 'Tühjenda järjekord';

  @override
  String get clearQueueQuestion =>
      'Kas olete kindel, et soovite järjekorra tühjendada?';

  @override
  String get clearRecentlyPlayed => 'Tühjenda hiljuti esitatud lood';

  @override
  String get clearRecentlyPlayedQuestion =>
      'Kas olete kindel, et soovite hiljuti esitatud lugude ajaloo tühjendada?';

  @override
  String get clearSearchHistory => 'Tühjenda otsinguajalugu';

  @override
  String get clearSearchHistoryQuestion =>
      'Kas olete kindel, et soovite otsinguajaloo tühjendada?';

  @override
  String get copy => 'Copy';

  @override
  String get confirm => 'Kinnita';

  @override
  String get confirmation => 'Kinnitus';

  @override
  String get copyLogs => 'Kopeeri logid';

  @override
  String get copyLogsNoLogs => 'Pole logisid kopeerimiseks';

  @override
  String get copyLogsSuccess => 'Logid edukalt kopeeritud';

  @override
  String get create => 'Loo';

  @override
  String get createFolder => 'Loo kaust';

  @override
  String get custom => 'Kohandatud';

  @override
  String get customPlaylistImgUrl => 'Kohandatud esitusloendi pildi URL';

  @override
  String get customPlaylistName => 'Kohandatud esitusloendi nimi';

  @override
  String get customPlaylists => 'Kohandatud esitusloendid';

  @override
  String get dateAdded => 'Lisamise kuupäev';

  @override
  String get default_ => 'Vaikimisi';

  @override
  String get delete => 'Kustuta';

  @override
  String get deleteDownloads => 'Kustuta allalaadimised';

  @override
  String get deleteDownloadsQuestion =>
      'Kas olete kindel, et soovite kõik allalaadimised kustutada?';

  @override
  String get deleteFolder => 'Kustuta kaust';

  @override
  String get deleteFolderQuestion =>
      'Kas olete kindel, et soovite selle kausta kustutada? Kaustas olevad esitusloendid liigutatakse põhiteeki.';

  @override
  String get deletePlaylist => 'Kustuta esitusloend';

  @override
  String get download => 'Laadi alla';

  @override
  String get downloadAppUpdate => 'Laadi rakenduse uuendus alla';

  @override
  String get downloadCancelled => 'Allalaadimine tühistatud';

  @override
  String get downloadFailed => 'Allalaadimine ebaõnnestus';

  @override
  String get downloadPlaylist => 'Laadi esitusloend alla';

  @override
  String get downloadsDeleted => 'Allalaadimised edukalt kustutatud';

  @override
  String get dynamicColor => 'Dünaamiline aktsentvärv (Android 12+)';

  @override
  String get dynamicColorDescription =>
      'Use the accent colors from your Android system theme.';

  @override
  String get editFolder => 'Muuda kausta';

  @override
  String get editPlaylist => 'Muuda esitusloendit';

  @override
  String get emptyFolderMsg =>
      'See kaust on tühi. Lisa esitusloendeid, et oma muusikat korraldada.';

  @override
  String get enableUpdateChecksDescription =>
      'Kas soovid, et SoundWave kontrolliks automaatselt uuendusi GitHubi väljalasetest? Uuendusi saab alati käsitsi kontrollida seadetest.';

  @override
  String get endOfSong => 'Loo lõpp';

  @override
  String get enterFolderName => 'Sisesta kausta nimi';

  @override
  String get equalizer => 'Ekvalaiser';

  @override
  String get equalizerAndroidOnly => 'Ekvalaiser on saadaval ainult Androidil.';

  @override
  String get equalizerBands => 'Ribad';

  @override
  String get equalizerDisabledHint =>
      'Ribade võimenduse muudatused on välja lülitatud.';

  @override
  String get equalizerEnable => 'Luba ekvalaiser';

  @override
  String get equalizerEnabledHint =>
      'Ribade võimenduse muudatused on aktiivsed.';

  @override
  String get equalizerInitFailed =>
      'Ekvalaiserit ei õnnestunud praegu käivitada. Proovi lugu esitada ja ava see leht uuesti.';

  @override
  String get equalizerPresetBalanced => 'Tasakaalustatud';

  @override
  String get equalizerPresetBassBoost => 'Bassivõimendus';

  @override
  String get equalizerPresetElectronic => 'Elektrooniline';

  @override
  String get equalizerPresetPop => 'Pop';

  @override
  String get equalizerPresetRock => 'Rock';

  @override
  String get equalizerPresetTrebleBoost => 'Kõrgete toonide võimendus';

  @override
  String get equalizerPresetVocal => 'Vokaal';

  @override
  String get equalizerPresets => 'Eelseaded';

  @override
  String get equalizerResetBands => 'Lähtesta ribad';

  @override
  String get error => 'Tekkis viga. Kontrolli logisid või proovi uuesti.';

  @override
  String get externalRecommendations => 'Välised soovitused';

  @override
  String get externalRecommendationsDescription =>
      'Kasuta soovituste jaoks välist algoritmi SoundWave enda algoritmi asemel.';

  @override
  String get failedPlayingRadio => 'Raadiojaama esitamine ebaõnnestus';

  @override
  String get failedToLoadPlaylist => 'Esitusloendi laadimine ebaõnnestus';

  @override
  String get fieldsNotEmpty => 'Kõik väljad tuleb täita';

  @override
  String get folderAlreadyExists => 'Sellise nimega kaust on juba olemas';

  @override
  String get folderDeleted => 'Kaust edukalt kustutatud';

  @override
  String get folderName => 'Kausta nimi';

  @override
  String get folderUpdated => 'Kaust edukalt uuendatud';

  @override
  String get goToArtist => 'Ava artist';

  @override
  String get home => 'Avaleht';

  @override
  String get hours => 'Tundi';

  @override
  String get imagePicked => 'Pilt valitud';

  @override
  String get importSpotifyPlaylist => 'Import playlist from Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Import Spotify playlist';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Export your Spotify playlist as CSV at chosic.com/spotify-playlist-exporter/, then choose the file or paste its contents below. SoundWave will search YouTube for each song.';

  @override
  String get chooseCsvFile => 'Choose CSV file';

  @override
  String get openChosicExporter => 'Open Chosic Spotify exporter';

  @override
  String get pasteCsv => 'Paste CSV';

  @override
  String get playlistName => 'Playlist name';

  @override
  String get importPlaylist => 'Import playlist';

  @override
  String get spotifyCsvHint => 'Paste CSV content here';

  @override
  String get spotifyPlaylistNameHint => 'Imported Spotify playlist';

  @override
  String get spotifyPlaylistEmpty =>
      'Choose a CSV file or paste CSV content first';

  @override
  String get enterPlaylistName => 'Please enter a playlist name';

  @override
  String get spotifyPlaylistInvalid =>
      'The CSV does not contain Song and Artist columns';

  @override
  String get spotifyPlaylistImporting => 'Importing playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found of $total songs imported';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Searching $done of $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'An import is already in progress';

  @override
  String get spotifyPlaylistMissingSongs => 'Songs not found';

  @override
  String get spotifyPlaylistImportFailed => 'Playlist import failed';

  @override
  String get invalidYouTubePlaylist => 'Vigane YouTube\'i esitusloend';

  @override
  String get language => 'Keel';

  @override
  String get languageDe => 'Saksa';

  @override
  String get languageEl => 'Kreeka';

  @override
  String get languageEn => 'Inglise';

  @override
  String get languageEs => 'Hispaania';

  @override
  String get languageEt => 'Eesti';

  @override
  String get languageFr => 'Prantsuse';

  @override
  String get languageHe => 'Heebrea';

  @override
  String get languageHi => 'Hindi';

  @override
  String get languageHu => 'Ungari';

  @override
  String get languageId => 'Indoneesia';

  @override
  String get languageIt => 'Itaalia';

  @override
  String get languageJa => 'Jaapani';

  @override
  String get languageKo => 'Korea';

  @override
  String get languageMsg => 'Keel edukalt uuendatud';

  @override
  String get languagePl => 'Poola';

  @override
  String get languagePt => 'Portugali';

  @override
  String get languageRu => 'Vene';

  @override
  String get languageSv => 'Rootsi';

  @override
  String get languageTa => 'Tamili';

  @override
  String get languageTr => 'Türgi';

  @override
  String get languageUk => 'Ukraina';

  @override
  String get languageZh => 'Hiina (lihtsustatud)';

  @override
  String get languageZhHant => 'Hiina (traditsiooniline)';

  @override
  String get library => 'Muusikakogu';

  @override
  String get licenses => 'Litsentsid';

  @override
  String get likedPlaylists => 'Lemmikesitusloendid';

  @override
  String get likedSongs => 'Lemmiklood';

  @override
  String get linkCopied => 'Esitusloendi link kopeeritud lõikelauale';

  @override
  String get listeningStats => 'Kuulamisstatistika';

  @override
  String get listeningStatsCleared => 'Kuulamisstatistika tühjendatud';

  @override
  String get listeningStatsDescription =>
      'Jälgi kohalikku kuulamisstatistikat kuu- ja aastakokkuvõteteks.';

  @override
  String get loading => 'Laadimine';

  @override
  String get lyrics => 'Sõnad';

  @override
  String get lyricsNotAvailable => 'Sõnad pole saadaval';

  @override
  String get makeOffline => 'Tee võrguühenduseta kasutatavaks';

  @override
  String get minutes => 'Minutit';

  @override
  String get minutesListened => 'kuulatud minutit';

  @override
  String get monthlyListeners => 'monthly listeners';

  @override
  String get moreOptions => 'Rohkem valikuid';

  @override
  String get mostPlayed => 'Enim esitatud';

  @override
  String get moveToFolder => 'Liiguta kausta';

  @override
  String get name => 'Nimi';

  @override
  String get newAnnouncement => 'Uus teadaanne postitatud';

  @override
  String get newFolder => 'Uus kaust';

  @override
  String get no => 'Ei';

  @override
  String get noCustomPlaylists => 'Kohandatud esitusloendeid pole veel loodud';

  @override
  String get noFolders => 'Kaustu pole veel loodud';

  @override
  String get noListeningStats => 'Kuulamisstatistikat pole veel';

  @override
  String get noOfflineLibraryContent =>
      'Võrguühenduseta sisu puudub. Luba võrgurežiim või laadi teegi kasutamiseks alla esitusloendid/lood.';

  @override
  String get noPlaylistsAdded => 'Esitusloendeid pole veel lisatud';

  @override
  String get noRadioStations => 'Raadiojaamu pole saadaval';

  @override
  String get noSongsInPlaylist => 'Esitusloendis pole lugusid';

  @override
  String get noSongsInQueue => 'Järjekorras pole lugusid';

  @override
  String get notYTlist => 'Vigane YouTube\'i esitusloendi ID';

  @override
  String get offlineMode => 'Võrguühenduseta režiim';

  @override
  String get offlineModeDescription =>
      'Lülita välja võrgufunktsioonid ja kasuta SoundWave\'t täielikult võrguühenduseta.';

  @override
  String get offlinePlaylists => 'Võrguühenduseta esitusloendid';

  @override
  String get offlineSongs => 'Võrguühenduseta lood';

  @override
  String get others => 'Muud';

  @override
  String get pause => 'Paus';

  @override
  String get pickImageFromDevice => 'Vali pilt seadmest';

  @override
  String get pinToLibrary => 'Kinnita muusikakogusse';

  @override
  String get pinnedPlaylists => 'Kinnitatud esitusloendid';

  @override
  String get pinnedPlaylistsLimit =>
      'Saad kinnitada kuni 5 esitusloendit või albumit';

  @override
  String get play => 'Esita';

  @override
  String get playNext => 'Esita järgmisena';

  @override
  String get playlist => 'Esitusloend';

  @override
  String get playlistAlreadyDownloaded => 'Esitusloend on juba alla laaditud';

  @override
  String get playlistAlreadyExists => 'Esitusloend on juba olemas';

  @override
  String get playlistDownloaded => 'Esitusloend alla laaditud';

  @override
  String get playlistEmpty => 'Esitusloend on tühi';

  @override
  String get playlistFolders => 'Esitusloendite kaustad';

  @override
  String get playlistRemovedFromOffline =>
      'Esitusloend eemaldati võrguühenduseta režiimist';

  @override
  String get playlistUpdated => 'Esitusloend edukalt uuendatud';

  @override
  String get playlists => 'Esitusloendid';

  @override
  String get preferences => 'Eelistused';

  @override
  String get provideIdOrNameError =>
      'Palun sisesta YouTube\'i ID või kohandatud esitusloendi nimi';

  @override
  String get pureBlackTheme => 'Täielik must teema';

  @override
  String get pureBlackThemeDescription =>
      'Use a true black background in dark mode for OLED displays.';

  @override
  String get queue => 'Järjekord';

  @override
  String get radioStations => 'Raadiojaamad';

  @override
  String get recentlyPlayed => 'Hiljuti esitatud';

  @override
  String get recentlyPlayedMsg => 'Hiljuti esitatud lugude ajalugu tühjendatud';

  @override
  String get recommendedForYou => 'Sulle soovitatud';

  @override
  String get remove => 'Eemalda';

  @override
  String get removeFromFolder => 'Eemalda kaustast';

  @override
  String get removeFromLikedPlaylists => 'Eemalda lemmikesitusloenditest';

  @override
  String get removeFromLikedSongs => 'Eemalda lemmiklugude hulgast';

  @override
  String get removeFromPlaylist => 'Eemalda esitusloendist';

  @override
  String get removeFromRecentlyPlayed =>
      'Eemalda hiljuti esitatud lugude hulgast';

  @override
  String get removeOffline => 'Eemalda võrguühenduseta režiimist';

  @override
  String get removeOfflinePlaylist =>
      'Eemalda esitusloend võrguühenduseta režiimist';

  @override
  String get removeOfflinePlaylistConfirm =>
      'See eemaldab esitusloendi võrguühenduseta režiimist. Lood, mida kasutatakse teistes esitusloendites, jäävad siiski kättesaadavaks.';

  @override
  String get removePlaylistQuestion =>
      'Kas olete kindel, et soovite selle esitusloendi eemaldada?';

  @override
  String get removeSearchQueryQuestion =>
      'Kas olete kindel, et soovite selle otsingupäringu eemaldada?';

  @override
  String get removedFromLikedSongs => 'Eemaldatud lemmiklugude hulgast';

  @override
  String get renameSong => 'Nimeta lugu ümber';

  @override
  String get repeat => 'Korda';

  @override
  String get replay => 'Esita uuesti';

  @override
  String get restoreError => 'Andmete taastamisel tekkis viga';

  @override
  String get restoreUserData => 'Taasta kasutajaandmed';

  @override
  String get restoredSuccess => 'Andmed edukalt taastatud';

  @override
  String get search => 'Otsi';

  @override
  String get searchHistoryMsg => 'Otsinguajalugu tühjendatud';

  @override
  String get selectDuration => 'Vali kestus';

  @override
  String get setTimer => 'Seadista taimer';

  @override
  String get settingChangedMsg => 'Seaded edukalt uuendatud';

  @override
  String get settings => 'Seaded';

  @override
  String get share => 'Jaga';

  @override
  String get shareRecap => 'Jaga kokkuvõtet';

  @override
  String get shareTimeMachineText => 'Minu SoundWave kokkuvõte';

  @override
  String get shuffle => 'Sega';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Singles & EPs';

  @override
  String get skipToNext => 'Järgmisele';

  @override
  String get skipToPrevious => 'Eelmisele';

  @override
  String get sleepTimer => 'Unetaimer';

  @override
  String get sleepTimerCancelled => 'Unetaimer tühistatud';

  @override
  String get sleepTimerSet => 'Unetaimer seatud';

  @override
  String get songAdded => 'Lugu lisatud';

  @override
  String get songAddedToOffline => 'Lugu on nüüd saadaval võrguühenduseta';

  @override
  String get songAlreadyInPlaylist => 'Lugu on juba esitusloendis';

  @override
  String get songRemoved => 'Lugu eemaldatud';

  @override
  String get songRemovedFromOffline =>
      'Lugu pole enam saadaval võrguühenduseta';

  @override
  String get songs => 'Lood';

  @override
  String get sponsorBlockDescription =>
      'Jäta vahele sponsoreeritud lõigud toetatud lugudes.';

  @override
  String get sponsorProject => 'Toeta projekti';

  @override
  String get suggestedArtists => 'Soovitatud artistid';

  @override
  String get suggestedPlaylists => 'Soovitatud esitusloendid';

  @override
  String get tapToView => 'Puuduta vaatamiseks';

  @override
  String get themeMode => 'Teemarežiim';

  @override
  String get themeModeDark => 'Tume';

  @override
  String get themeModeLight => 'Hele';

  @override
  String get themeModeSystem => 'Süsteem';

  @override
  String get timeMachine => 'Ajamasin';

  @override
  String get tools => 'Tööriistad';

  @override
  String get topSongs => 'Top songs';

  @override
  String get translate => 'Tõlgi';

  @override
  String get translateDescription =>
      'Aita tõlkida SoundWave oma keelde Crowdinis.';

  @override
  String get understand => 'Sain aru';

  @override
  String get undo => 'Võta tagasi';

  @override
  String get unpinFromLibrary => 'Eemalda kinnitus muusikakogust';

  @override
  String get update => 'Uuenda';

  @override
  String get useProxy => 'Kasuta proksit';

  @override
  String get useProxyDescription =>
      'Kasuta proksit ainult siis, kui voogesitus ebaõnnestub; tarbetu kasutamine võib esituse katkestada.';

  @override
  String get userPlaylists => 'Kasutaja esitusloendid';

  @override
  String get yes => 'Jah';

  @override
  String get youtubePlaylistLinkOrId => 'YouTube\'i esitusloendi link või ID';
}
