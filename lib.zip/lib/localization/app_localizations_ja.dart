// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Japanese (`ja`).
class AppLocalizationsJa extends AppLocalizations {
  AppLocalizationsJa([String locale = 'ja']) : super(locale);

  @override
  String get about => 'アプリについて';

  @override
  String get accentChangeMsg => 'アクセントカラーを変更しました';

  @override
  String get accentColor => 'アクセントカラー';

  @override
  String get add => '追加';

  @override
  String get addPlaylist => 'プレイリストを追加';

  @override
  String get addToLikedPlaylists => 'お気に入りのプレイリストに追加';

  @override
  String get addToLikedSongs => 'お気に入りの曲に追加';

  @override
  String get addToPlaylist => 'プレイリストに追加';

  @override
  String get addToQueue => 'キューに追加';

  @override
  String get addedPlaylists => '追加済みのプレイリスト';

  @override
  String get addedSuccess => '追加しました';

  @override
  String get addedToLikedSongs => 'お気に入りの曲に追加しました';

  @override
  String get album => 'アルバム';

  @override
  String get albums => 'アルバム';

  @override
  String get allSongs => 'All songs';

  @override
  String get alreadyDownloading => 'すでにダウンロード中です';

  @override
  String get annualRecap => '年間まとめ';

  @override
  String get appUpdateIsAvailable => 'アプリのアップデートがあります';

  @override
  String get artist => 'アーティスト';

  @override
  String get artistNotFound => 'Artist not found. Check logs or try again.';

  @override
  String get artists => 'アーティスト';

  @override
  String get audioQuality => '音質';

  @override
  String get audioQualityBadge => 'Show audio quality badge';

  @override
  String get audioQualityBadgeDescription =>
      'Display a small bitrate/codec badge on the now playing artwork.';

  @override
  String get audioQualityHigh => '高音質';

  @override
  String get audioQualityLow => '低音質';

  @override
  String get audioQualityMedium => '中音質';

  @override
  String get audioQualityMsg => '音質を変更しました';

  @override
  String get automaticSongPicker => '自動曲選択';

  @override
  String get automaticSongPickerDescription => '現在の曲が終了した後、自動的にランダムな曲を再生します。';

  @override
  String get automaticUpdateChecks => '自動アップデート確認';

  @override
  String get automaticUpdateChecksDescription => '起動時にアプリのアップデートを自動的に確認します。';

  @override
  String get back => '戻る';

  @override
  String get backToFavorites => 'お気に入りに戻る';

  @override
  String get backedupSuccess => 'データを正常にバックアップしました';

  @override
  String get backupError => 'データのバックアップ中にエラーが発生しました';

  @override
  String get backupUserData => 'ユーザーデータをバックアップ';

  @override
  String get becomeSponsor => 'スポンサーになる';

  @override
  String get cacheMsg => 'キャッシュを削除しました';

  @override
  String get cancel => 'キャンセル';

  @override
  String get cancellingDownload => 'ダウンロードをキャンセルしています...';

  @override
  String get checkForUpdates => 'アップデートを確認しますか？';

  @override
  String get chooseBackupDir => 'バックアップ先フォルダーを選択';

  @override
  String get chooseBackupFiles => 'バックアップするファイルを選択';

  @override
  String get clear => '消去';

  @override
  String get clearCache => 'キャッシュを削除';

  @override
  String get clearListeningStats => 'リスニング統計を削除';

  @override
  String get clearListeningStatsQuestion =>
      'この端末に保存されたTime Machineのリスニング統計が削除されます。続行しますか？';

  @override
  String get clearQueue => 'キューを削除';

  @override
  String get clearQueueQuestion => 'キューを削除してもよろしいですか？';

  @override
  String get clearRecentlyPlayed => '再生履歴を削除';

  @override
  String get clearRecentlyPlayedQuestion => '再生履歴を削除してもよろしいですか？';

  @override
  String get clearSearchHistory => '検索履歴を削除';

  @override
  String get clearSearchHistoryQuestion => '検索履歴を削除してもよろしいですか？';

  @override
  String get copy => 'Copy';

  @override
  String get confirm => '確認';

  @override
  String get confirmation => '確認';

  @override
  String get copyLogs => 'ログをコピー';

  @override
  String get copyLogsNoLogs => 'コピーできるログはありません';

  @override
  String get copyLogsSuccess => 'ログをコピーしました';

  @override
  String get create => '作成';

  @override
  String get createFolder => 'フォルダーを作成';

  @override
  String get custom => 'カスタム';

  @override
  String get customPlaylistImgUrl => 'カスタムプレイリスト画像URL';

  @override
  String get customPlaylistName => 'カスタムプレイリスト名';

  @override
  String get customPlaylists => 'カスタムプレイリスト';

  @override
  String get dateAdded => '追加日';

  @override
  String get default_ => 'デフォルト';

  @override
  String get delete => '削除';

  @override
  String get deleteDownloads => 'ダウンロードを削除';

  @override
  String get deleteDownloadsQuestion => 'すべてのダウンロードを削除してもよろしいですか？';

  @override
  String get deleteFolder => 'フォルダーを削除';

  @override
  String get deleteFolderQuestion =>
      'このフォルダーを削除しますか？フォルダー内のプレイリストはメインライブラリへ移動されます。';

  @override
  String get deletePlaylist => 'プレイリストを削除';

  @override
  String get download => 'ダウンロード';

  @override
  String get downloadAppUpdate => 'アプリのアップデートをダウンロード';

  @override
  String get downloadCancelled => 'ダウンロードをキャンセルしました';

  @override
  String get downloadFailed => 'ダウンロードに失敗しました';

  @override
  String get downloadPlaylist => 'プレイリストをダウンロード';

  @override
  String get downloadsDeleted => 'ダウンロードを削除しました';

  @override
  String get dynamicColor => '動的アクセントカラー (Android 12以上)';

  @override
  String get dynamicColorDescription =>
      'Use the accent colors from your Android system theme.';

  @override
  String get editFolder => 'フォルダーを編集';

  @override
  String get editPlaylist => 'プレイリストを編集';

  @override
  String get emptyFolderMsg => 'このフォルダーは空です。プレイリストを追加して音楽を整理しましょう。';

  @override
  String get enableUpdateChecksDescription =>
      'SoundWaveがGitHubのリリースから自動的にアップデートを確認するようにしますか？設定からいつでも手動で確認できます。';

  @override
  String get endOfSong => '曲の終わり';

  @override
  String get enterFolderName => 'フォルダー名を入力してください';

  @override
  String get equalizer => 'イコライザー';

  @override
  String get equalizerAndroidOnly => 'イコライザーはAndroidでのみ利用できます。';

  @override
  String get equalizerBands => 'バンド';

  @override
  String get equalizerDisabledHint => 'バンドのゲイン調整は無効になっています。';

  @override
  String get equalizerEnable => 'イコライザーを有効にする';

  @override
  String get equalizerEnabledHint => 'バンドのゲイン調整が有効です。';

  @override
  String get equalizerInitFailed =>
      '現在イコライザーを初期化できませんでした。曲を再生してからこのページを再度開いてください。';

  @override
  String get equalizerPresetBalanced => 'バランス';

  @override
  String get equalizerPresetBassBoost => '低音強調';

  @override
  String get equalizerPresetElectronic => 'エレクトロニック';

  @override
  String get equalizerPresetPop => 'ポップ';

  @override
  String get equalizerPresetRock => 'ロック';

  @override
  String get equalizerPresetTrebleBoost => '高音強調';

  @override
  String get equalizerPresetVocal => 'ボーカル';

  @override
  String get equalizerPresets => 'プリセット';

  @override
  String get equalizerResetBands => 'バンドをリセット';

  @override
  String get error => 'エラーが発生しました。ログを確認するか、もう一度お試しください。';

  @override
  String get externalRecommendations => '外部おすすめ機能';

  @override
  String get externalRecommendationsDescription =>
      'SoundWave独自のアルゴリズムではなく、外部アルゴリズムをおすすめに使用します。';

  @override
  String get failedPlayingRadio => 'ラジオ局の再生に失敗しました';

  @override
  String get failedToLoadPlaylist => 'プレイリストの読み込みに失敗しました';

  @override
  String get fieldsNotEmpty => 'すべての項目を入力してください';

  @override
  String get folderAlreadyExists => '同じ名前のフォルダーがすでに存在します';

  @override
  String get folderDeleted => 'フォルダーを削除しました';

  @override
  String get folderName => 'フォルダー名';

  @override
  String get folderUpdated => 'フォルダーを更新しました';

  @override
  String get goToArtist => 'アーティストを表示';

  @override
  String get home => 'ホーム';

  @override
  String get hours => '時間';

  @override
  String get imagePicked => '画像を選択しました';

  @override
  String get importSpotifyPlaylist => 'Import playlist from Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Import Spotify playlist';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Export your Spotify playlist as CSV at chosic.com/spotify-playlist-exporter/, then choose the file or paste its contents below. SoundWave will search YouTube for each song.';

  @override
  String get chooseCsvFile => 'Choose CSV file';

  @override
  String get openChosicExporter => 'Open Chosic Spotify exporter';

  @override
  String get pasteCsv => 'Paste CSV';

  @override
  String get playlistName => 'Playlist name';

  @override
  String get importPlaylist => 'Import playlist';

  @override
  String get spotifyCsvHint => 'Paste CSV content here';

  @override
  String get spotifyPlaylistNameHint => 'Imported Spotify playlist';

  @override
  String get spotifyPlaylistEmpty =>
      'Choose a CSV file or paste CSV content first';

  @override
  String get enterPlaylistName => 'Please enter a playlist name';

  @override
  String get spotifyPlaylistInvalid =>
      'The CSV does not contain Song and Artist columns';

  @override
  String get spotifyPlaylistImporting => 'Importing playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found of $total songs imported';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Searching $done of $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'An import is already in progress';

  @override
  String get spotifyPlaylistMissingSongs => 'Songs not found';

  @override
  String get spotifyPlaylistImportFailed => 'Playlist import failed';

  @override
  String get invalidYouTubePlaylist => '無効なYouTubeプレイリスト';

  @override
  String get language => '言語';

  @override
  String get languageDe => 'ドイツ語';

  @override
  String get languageEl => 'ギリシャ語';

  @override
  String get languageEn => '英語';

  @override
  String get languageEs => 'スペイン語';

  @override
  String get languageEt => 'エストニア語';

  @override
  String get languageFr => 'フランス語';

  @override
  String get languageHe => 'ヘブライ語';

  @override
  String get languageHi => 'ヒンディー語';

  @override
  String get languageHu => 'ハンガリー語';

  @override
  String get languageId => 'インドネシア語';

  @override
  String get languageIt => 'イタリア語';

  @override
  String get languageJa => '日本語';

  @override
  String get languageKo => '韓国語';

  @override
  String get languageMsg => '言語を変更しました';

  @override
  String get languagePl => 'ポーランド語';

  @override
  String get languagePt => 'ポルトガル語';

  @override
  String get languageRu => 'ロシア語';

  @override
  String get languageSv => 'スウェーデン語';

  @override
  String get languageTa => 'タミル語';

  @override
  String get languageTr => 'トルコ語';

  @override
  String get languageUk => 'ウクライナ語';

  @override
  String get languageZh => '中国語（簡体字）';

  @override
  String get languageZhHant => '中国語（繁体字）';

  @override
  String get library => 'ライブラリ';

  @override
  String get licenses => 'ライセンス';

  @override
  String get likedPlaylists => 'お気に入りのプレイリスト';

  @override
  String get likedSongs => 'お気に入りの曲';

  @override
  String get linkCopied => 'プレイリストのリンクをクリップボードにコピーしました';

  @override
  String get listeningStats => 'リスニング統計';

  @override
  String get listeningStatsCleared => 'リスニング統計を削除しました';

  @override
  String get listeningStatsDescription => '月間・年間まとめのために、ローカルのリスニング統計を記録します。';

  @override
  String get loading => '読み込み中';

  @override
  String get lyrics => '歌詞';

  @override
  String get lyricsNotAvailable => '歌詞は利用できません';

  @override
  String get makeOffline => 'オフラインで利用可能にする';

  @override
  String get minutes => '分';

  @override
  String get minutesListened => '再生時間（分）';

  @override
  String get monthlyListeners => 'monthly listeners';

  @override
  String get moreOptions => 'その他のオプション';

  @override
  String get mostPlayed => '最も再生された曲';

  @override
  String get moveToFolder => 'フォルダーに移動';

  @override
  String get name => '名前';

  @override
  String get newAnnouncement => '新しいお知らせを投稿しました';

  @override
  String get newFolder => '新規フォルダー';

  @override
  String get no => 'いいえ';

  @override
  String get noCustomPlaylists => 'まだカスタムプレイリストはありません';

  @override
  String get noFolders => 'まだフォルダーはありません';

  @override
  String get noListeningStats => 'リスニング統計はまだありません';

  @override
  String get noOfflineLibraryContent =>
      'オフラインコンテンツがありません。オンラインモードを有効にするか、プレイリストや曲をダウンロードしてライブラリを使用してください。';

  @override
  String get noPlaylistsAdded => 'まだプレイリストは追加されていません';

  @override
  String get noRadioStations => '利用可能なラジオ局はありません';

  @override
  String get noSongsInPlaylist => 'プレイリストに曲がありません';

  @override
  String get noSongsInQueue => 'キューに曲がありません';

  @override
  String get notYTlist => '無効なYouTubeプレイリストID';

  @override
  String get offlineMode => 'オフラインモード';

  @override
  String get offlineModeDescription =>
      'オンライン機能を無効にして、SoundWaveを完全にオフラインで使用します。';

  @override
  String get offlinePlaylists => 'オフラインプレイリスト';

  @override
  String get offlineSongs => 'オフライン曲';

  @override
  String get others => 'その他';

  @override
  String get pause => '一時停止';

  @override
  String get pickImageFromDevice => '端末から画像を選択';

  @override
  String get pinToLibrary => 'ライブラリに固定';

  @override
  String get pinnedPlaylists => '固定済み';

  @override
  String get pinnedPlaylistsLimit => '最大5つのプレイリストまたはアルバムを固定できます';

  @override
  String get play => '再生';

  @override
  String get playNext => '次に再生';

  @override
  String get playlist => 'プレイリスト';

  @override
  String get playlistAlreadyDownloaded => 'プレイリストはすでにダウンロードされています';

  @override
  String get playlistAlreadyExists => 'プレイリストはすでに存在します';

  @override
  String get playlistDownloaded => 'プレイリストをダウンロードしました';

  @override
  String get playlistEmpty => 'プレイリストは空です';

  @override
  String get playlistFolders => 'プレイリストフォルダー';

  @override
  String get playlistRemovedFromOffline => 'プレイリストをオフラインから削除しました';

  @override
  String get playlistUpdated => 'プレイリストを更新しました';

  @override
  String get playlists => 'プレイリスト';

  @override
  String get preferences => '環境設定';

  @override
  String get provideIdOrNameError => 'YouTubeプレイリストIDまたはカスタムプレイリスト名を入力してください';

  @override
  String get pureBlackTheme => '完全な黒テーマ';

  @override
  String get pureBlackThemeDescription =>
      'Use a true black background in dark mode for OLED displays.';

  @override
  String get queue => 'キュー';

  @override
  String get radioStations => 'ラジオ局';

  @override
  String get recentlyPlayed => '最近再生した曲';

  @override
  String get recentlyPlayedMsg => '最近の再生履歴を削除しました';

  @override
  String get recommendedForYou => 'あなたへのおすすめ';

  @override
  String get remove => '削除';

  @override
  String get removeFromFolder => 'フォルダーから削除';

  @override
  String get removeFromLikedPlaylists => 'お気に入りのプレイリストから削除';

  @override
  String get removeFromLikedSongs => 'お気に入りの曲から削除';

  @override
  String get removeFromPlaylist => 'プレイリストから削除';

  @override
  String get removeFromRecentlyPlayed => '最近再生した曲から削除';

  @override
  String get removeOffline => 'オフラインから削除';

  @override
  String get removeOfflinePlaylist => 'オフラインプレイリストから削除';

  @override
  String get removeOfflinePlaylistConfirm =>
      'このプレイリストをオフラインから削除します。他のプレイリストで使用されている曲は引き続き利用できます。';

  @override
  String get removePlaylistQuestion => 'このプレイリストを削除してもよろしいですか？';

  @override
  String get removeSearchQueryQuestion => 'この検索履歴を削除してもよろしいですか？';

  @override
  String get removedFromLikedSongs => 'お気に入りの曲から削除しました';

  @override
  String get renameSong => '曲名を変更';

  @override
  String get repeat => 'リピート';

  @override
  String get replay => 'もう一度再生';

  @override
  String get restoreError => 'データの復元中にエラーが発生しました';

  @override
  String get restoreUserData => 'ユーザーデータを復元';

  @override
  String get restoredSuccess => 'データを正常に復元しました';

  @override
  String get search => '検索';

  @override
  String get searchHistoryMsg => '検索履歴を削除しました';

  @override
  String get selectDuration => '時間を選択';

  @override
  String get setTimer => 'タイマーを設定';

  @override
  String get settingChangedMsg => '設定を変更しました';

  @override
  String get settings => '設定';

  @override
  String get share => '共有';

  @override
  String get shareRecap => 'まとめを共有';

  @override
  String get shareTimeMachineText => 'My SoundWaveまとめ';

  @override
  String get shuffle => 'シャッフル';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Singles & EPs';

  @override
  String get skipToNext => '次へスキップ';

  @override
  String get skipToPrevious => '前へスキップ';

  @override
  String get sleepTimer => 'スリープタイマー';

  @override
  String get sleepTimerCancelled => 'スリープタイマーをキャンセルしました';

  @override
  String get sleepTimerSet => 'スリープタイマーを設定しました';

  @override
  String get songAdded => '曲を追加しました';

  @override
  String get songAddedToOffline => '曲をオフラインで利用できるようになりました';

  @override
  String get songAlreadyInPlaylist => '曲はすでにプレイリストにあります';

  @override
  String get songRemoved => '曲を削除しました';

  @override
  String get songRemovedFromOffline => '曲をオフラインで利用できなくしました';

  @override
  String get songs => '曲';

  @override
  String get sponsorBlockDescription => '対応している曲のスポンサー部分をスキップします。';

  @override
  String get sponsorProject => 'プロジェクトを支援';

  @override
  String get suggestedArtists => 'おすすめアーティスト';

  @override
  String get suggestedPlaylists => 'おすすめプレイリスト';

  @override
  String get tapToView => 'タップして表示';

  @override
  String get themeMode => 'テーマモード';

  @override
  String get themeModeDark => 'ダーク';

  @override
  String get themeModeLight => 'ライト';

  @override
  String get themeModeSystem => 'システム';

  @override
  String get timeMachine => 'Time Machine';

  @override
  String get tools => 'ツール';

  @override
  String get topSongs => 'Top songs';

  @override
  String get translate => '翻訳';

  @override
  String get translateDescription => 'CrowdinでSoundWaveの翻訳に協力してください。';

  @override
  String get understand => '理解しました';

  @override
  String get undo => '元に戻す';

  @override
  String get unpinFromLibrary => 'ライブラリから固定を解除';

  @override
  String get update => '更新';

  @override
  String get useProxy => 'プロキシを使用';

  @override
  String get useProxyDescription =>
      'ストリーミングに失敗した場合のみプロキシを使用してください。不必要な使用は再生に問題を引き起こす可能性があります。';

  @override
  String get userPlaylists => 'ユーザープレイリスト';

  @override
  String get yes => 'はい';

  @override
  String get youtubePlaylistLinkOrId => 'YouTubeプレイリストのリンクまたはID';
}
