// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Swedish (`sv`).
class AppLocalizationsSv extends AppLocalizations {
  AppLocalizationsSv([String locale = 'sv']) : super(locale);

  @override
  String get about => 'Om';

  @override
  String get accentChangeMsg => 'Accentfärgen har uppdaterats';

  @override
  String get accentColor => 'Accentfärg';

  @override
  String get add => 'Lägg till';

  @override
  String get addPlaylist => 'Lägg till spellista';

  @override
  String get addToLikedPlaylists => 'Lägg till i gillade spellistor';

  @override
  String get addToLikedSongs => 'Lägg till gillade låtar';

  @override
  String get addToPlaylist => 'Lägg till i spellista';

  @override
  String get addToQueue => 'Lägg till i kö';

  @override
  String get addedPlaylists => 'Tillagda spellistor';

  @override
  String get addedSuccess => 'Tillagd';

  @override
  String get addedToLikedSongs => 'Tillagd till gillade låtar';

  @override
  String get album => 'Album';

  @override
  String get albums => 'Album';

  @override
  String get allSongs => 'All songs';

  @override
  String get alreadyDownloading => 'Laddar redan ner';

  @override
  String get annualRecap => 'Annual recap';

  @override
  String get appUpdateIsAvailable => 'En uppdatering är tillgänglig';

  @override
  String get artist => 'Artist';

  @override
  String get artistNotFound => 'Artist not found. Check logs or try again.';

  @override
  String get artists => 'Artists';

  @override
  String get audioQuality => 'Ljudkvalitet';

  @override
  String get audioQualityBadge => 'Show audio quality badge';

  @override
  String get audioQualityBadgeDescription =>
      'Display a small bitrate/codec badge on the now playing artwork.';

  @override
  String get audioQualityHigh => 'High';

  @override
  String get audioQualityLow => 'Low';

  @override
  String get audioQualityMedium => 'Medium';

  @override
  String get audioQualityMsg => 'Ljudkvaliteten uppdaterad';

  @override
  String get automaticSongPicker => 'Automatisk låtväljare';

  @override
  String get automaticSongPickerDescription =>
      'Automatically play a random song after the current track ends.';

  @override
  String get automaticUpdateChecks => 'Automatic update checks';

  @override
  String get automaticUpdateChecksDescription =>
      'Automatically check for app updates on startup.';

  @override
  String get back => 'Tillbaka';

  @override
  String get backToFavorites => 'Tillbaka till favoriter';

  @override
  String get backedupSuccess => 'Data har säkerhetskopierats';

  @override
  String get backupError => 'Fel uppstod när data säkerhetskopierades';

  @override
  String get backupUserData => 'Säkerhetskopiera användardata';

  @override
  String get becomeSponsor => 'Bli sponsor';

  @override
  String get cacheMsg => 'Cacheminnet har rensats';

  @override
  String get cancel => 'Avbryt';

  @override
  String get cancellingDownload => 'Avbryter nedladdningen...';

  @override
  String get checkForUpdates => 'Check for Updates?';

  @override
  String get chooseBackupDir => 'Välj mapp för säkerhetskopia';

  @override
  String get chooseBackupFiles => 'Välj filer för säkerhetskopiering';

  @override
  String get clear => 'Rensa';

  @override
  String get clearCache => 'Rensa cacheminnet';

  @override
  String get clearListeningStats => 'Clear listening stats';

  @override
  String get clearListeningStatsQuestion =>
      'This will delete Time Machine listening stats stored on this device. Continue?';

  @override
  String get clearQueue => 'Rensa kö';

  @override
  String get clearQueueQuestion => 'Är du säker på att du vill tömma kön?';

  @override
  String get clearRecentlyPlayed => 'Rensa senast spelade';

  @override
  String get clearRecentlyPlayedQuestion =>
      'Är du säker på att du vill rensa historiken över senast spelade?';

  @override
  String get clearSearchHistory => 'Rensa sökhistorik';

  @override
  String get clearSearchHistoryQuestion =>
      'Är du säker på att du vill rensa sökhistoriken?';

  @override
  String get copy => 'Copy';

  @override
  String get confirm => 'Bekräfta';

  @override
  String get confirmation => 'Bekräftelse';

  @override
  String get copyLogs => 'Kopiera loggar';

  @override
  String get copyLogsNoLogs => 'Inga loggar att kopiera';

  @override
  String get copyLogsSuccess => 'Loggarna har kopierats';

  @override
  String get create => 'Create';

  @override
  String get createFolder => 'Create folder';

  @override
  String get custom => 'Beställnings';

  @override
  String get customPlaylistImgUrl => 'Anpassad spellistsavbildswebbadress';

  @override
  String get customPlaylistName => 'Anpassat spellistsnamn';

  @override
  String get customPlaylists => 'Anpassade spellistor';

  @override
  String get dateAdded => 'Date Added';

  @override
  String get default_ => 'Default';

  @override
  String get delete => 'Delete';

  @override
  String get deleteDownloads => 'Ta bort nedladdningar';

  @override
  String get deleteDownloadsQuestion =>
      'Är du säker på att du vill radera alla nedladdningar?';

  @override
  String get deleteFolder => 'Delete folder';

  @override
  String get deleteFolderQuestion =>
      'Are you sure you want to delete this folder? Playlists inside will be moved to the main library.';

  @override
  String get deletePlaylist => 'Ta bort spellista';

  @override
  String get download => 'Ladda ner';

  @override
  String get downloadAppUpdate => 'Ladda ner appuppdatering';

  @override
  String get downloadCancelled => 'Nerladdningen avbruten';

  @override
  String get downloadFailed => 'Nerladdningen misslyckades';

  @override
  String get downloadPlaylist => 'Ladda ner spellista';

  @override
  String get downloadsDeleted => 'Nedladdningar har raderats';

  @override
  String get dynamicColor => 'Dynamisk accentfärg (Android 12+)';

  @override
  String get dynamicColorDescription =>
      'Use the accent colors from your Android system theme.';

  @override
  String get editFolder => 'Redigera mapp';

  @override
  String get editPlaylist => 'Redigera spellista';

  @override
  String get emptyFolderMsg =>
      'This folder is empty. Add playlists to organize your music.';

  @override
  String get enableUpdateChecksDescription =>
      'Would you like SoundWave to check for updates automatically from GitHub releases? You can always check for updates manually from the settings';

  @override
  String get endOfSong => 'Låtens slut';

  @override
  String get enterFolderName => 'Please enter a folder name';

  @override
  String get equalizer => 'Utjämnare';

  @override
  String get equalizerAndroidOnly =>
      'Utjämnare är endast tillgänglig på Android.';

  @override
  String get equalizerBands => 'Band';

  @override
  String get equalizerDisabledHint =>
      'Justeringar av bandförstärkning kringgås.';

  @override
  String get equalizerEnable => 'Aktivera utjämnare';

  @override
  String get equalizerEnabledHint => 'Bandförstärkningsjusteringar är aktiva.';

  @override
  String get equalizerInitFailed =>
      'Utjämnare kunde inte initieras just nu. Försök spela en låt och öppna sidan igen.';

  @override
  String get equalizerPresetBalanced => 'Balanserad';

  @override
  String get equalizerPresetBassBoost => 'Basförstärkning';

  @override
  String get equalizerPresetElectronic => 'Elektronisk';

  @override
  String get equalizerPresetPop => 'Pop';

  @override
  String get equalizerPresetRock => 'Sten';

  @override
  String get equalizerPresetTrebleBoost => 'Diskant Boost';

  @override
  String get equalizerPresetVocal => 'Sång';

  @override
  String get equalizerPresets => 'Presenter';

  @override
  String get equalizerResetBands => 'Återställ band';

  @override
  String get error =>
      'Ett fel uppstod. Kontrollera loggarna eller försök igen.';

  @override
  String get externalRecommendations => 'Externa rekommendationer';

  @override
  String get externalRecommendationsDescription =>
      'Använd den externa algoritmen för rekommendationer istället för SoundWaves egen.';

  @override
  String get failedPlayingRadio => 'Failed to play radio station';

  @override
  String get failedToLoadPlaylist => 'Misslyckades med att ladda spellistan';

  @override
  String get fieldsNotEmpty => 'Alla fält måste fyllas i';

  @override
  String get folderAlreadyExists => 'A folder with this name already exists';

  @override
  String get folderDeleted => 'Folder deleted successfully';

  @override
  String get folderName => 'Folder name';

  @override
  String get folderUpdated => 'Mappen har uppdaterats';

  @override
  String get goToArtist => 'Go to artist';

  @override
  String get home => 'Hem';

  @override
  String get hours => 'Timmar';

  @override
  String get imagePicked => 'Bild vald';

  @override
  String get importSpotifyPlaylist => 'Import playlist from Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Import Spotify playlist';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Export your Spotify playlist as CSV at chosic.com/spotify-playlist-exporter/, then choose the file or paste its contents below. SoundWave will search YouTube for each song.';

  @override
  String get chooseCsvFile => 'Choose CSV file';

  @override
  String get openChosicExporter => 'Open Chosic Spotify exporter';

  @override
  String get pasteCsv => 'Paste CSV';

  @override
  String get playlistName => 'Playlist name';

  @override
  String get importPlaylist => 'Import playlist';

  @override
  String get spotifyCsvHint => 'Paste CSV content here';

  @override
  String get spotifyPlaylistNameHint => 'Imported Spotify playlist';

  @override
  String get spotifyPlaylistEmpty =>
      'Choose a CSV file or paste CSV content first';

  @override
  String get enterPlaylistName => 'Please enter a playlist name';

  @override
  String get spotifyPlaylistInvalid =>
      'The CSV does not contain Song and Artist columns';

  @override
  String get spotifyPlaylistImporting => 'Importing playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found of $total songs imported';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Searching $done of $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'An import is already in progress';

  @override
  String get spotifyPlaylistMissingSongs => 'Songs not found';

  @override
  String get spotifyPlaylistImportFailed => 'Playlist import failed';

  @override
  String get invalidYouTubePlaylist => 'Ogiltig YouTube-spellista';

  @override
  String get language => 'Språk';

  @override
  String get languageDe => 'Tyska';

  @override
  String get languageEl => 'Grekiska';

  @override
  String get languageEn => 'Engelska';

  @override
  String get languageEs => 'Spanska';

  @override
  String get languageEt => 'Estniska';

  @override
  String get languageFr => 'Franska';

  @override
  String get languageHe => 'Hebreiska';

  @override
  String get languageHi => 'Hindi';

  @override
  String get languageHu => 'Ungerska';

  @override
  String get languageId => 'Indonesiska';

  @override
  String get languageIt => 'Italienska';

  @override
  String get languageJa => 'Japanese';

  @override
  String get languageKo => 'Korean';

  @override
  String get languageMsg => 'Språket har uppdaterats';

  @override
  String get languagePl => 'Polish';

  @override
  String get languagePt => 'Portuguese';

  @override
  String get languageRu => 'Russian';

  @override
  String get languageSv => 'Swedish';

  @override
  String get languageTa => 'Tamil';

  @override
  String get languageTr => 'Turkish';

  @override
  String get languageUk => 'Ukrainian';

  @override
  String get languageZh => 'Chinese (Simplified)';

  @override
  String get languageZhHant => 'Chinese (Traditional)';

  @override
  String get library => 'Bibliotek';

  @override
  String get licenses => 'Licenser';

  @override
  String get likedPlaylists => 'Gillade spellistor';

  @override
  String get likedSongs => 'Gillade låtar';

  @override
  String get linkCopied => 'Playlist link copied to clipboard';

  @override
  String get listeningStats => 'Listening stats';

  @override
  String get listeningStatsCleared => 'Listening stats cleared';

  @override
  String get listeningStatsDescription =>
      'Track local listening stats for monthly and yearly recaps.';

  @override
  String get loading => 'Loading';

  @override
  String get lyrics => 'Låttext';

  @override
  String get lyricsNotAvailable => 'Låttexten är inte tillgänglig';

  @override
  String get makeOffline => 'Gör tillgänglig frånkopplad';

  @override
  String get minutes => 'Minuter';

  @override
  String get minutesListened => 'minutes listened';

  @override
  String get monthlyListeners => 'monthly listeners';

  @override
  String get moreOptions => 'More options';

  @override
  String get mostPlayed => 'Most played';

  @override
  String get moveToFolder => 'Move to folder';

  @override
  String get name => 'Namn';

  @override
  String get newAnnouncement => 'Nytt meddelande publicerat';

  @override
  String get newFolder => 'New folder';

  @override
  String get no => 'No';

  @override
  String get noCustomPlaylists => 'Inga anpassade spellistor har skapats än';

  @override
  String get noFolders => 'No folders created yet';

  @override
  String get noListeningStats => 'No listening stats yet';

  @override
  String get noOfflineLibraryContent =>
      'No offline content. Enable online mode or download playlists/songs to use the library.';

  @override
  String get noPlaylistsAdded => 'No playlists added yet';

  @override
  String get noRadioStations => 'No radio stations available';

  @override
  String get noSongsInPlaylist => 'No songs in playlist';

  @override
  String get noSongsInQueue => 'Inga låtar i kön';

  @override
  String get notYTlist => 'Ogiltigt ID för YouTube-spellista';

  @override
  String get offlineMode => 'Offlineläge';

  @override
  String get offlineModeDescription =>
      'Disable online features and use SoundWave completely offline.';

  @override
  String get offlinePlaylists => 'Offlinespellistor';

  @override
  String get offlineSongs => 'Offlinelåtar';

  @override
  String get others => 'Andra';

  @override
  String get pause => 'Pause';

  @override
  String get pickImageFromDevice => 'Välj bild från enheten';

  @override
  String get pinToLibrary => 'Pin to library';

  @override
  String get pinnedPlaylists => 'Pinned';

  @override
  String get pinnedPlaylistsLimit => 'You can pin up to 5 playlists or albums';

  @override
  String get play => 'Play';

  @override
  String get playNext => 'Spela nästa';

  @override
  String get playlist => 'Spellista';

  @override
  String get playlistAlreadyDownloaded => 'Spellistan har redan laddats ner';

  @override
  String get playlistAlreadyExists => 'Spellistan finns redan';

  @override
  String get playlistDownloaded => 'Spellista nerladdad';

  @override
  String get playlistEmpty => 'Spellistan är tom';

  @override
  String get playlistFolders => 'Playlist folders';

  @override
  String get playlistRemovedFromOffline =>
      'Spellista borttagen från offlinelagring';

  @override
  String get playlistUpdated => 'Spellistan har uppdaterats';

  @override
  String get playlists => 'Spellistor';

  @override
  String get preferences => 'Inställningar';

  @override
  String get provideIdOrNameError =>
      'Ange ett YouTube-ID eller ett anpassat spellistanamn';

  @override
  String get pureBlackTheme => 'Svart tema';

  @override
  String get pureBlackThemeDescription =>
      'Use a true black background in dark mode for OLED displays.';

  @override
  String get queue => 'Queue';

  @override
  String get radioStations => 'Radio Stations';

  @override
  String get recentlyPlayed => 'Senaste spelade';

  @override
  String get recentlyPlayedMsg => 'Historiken för senaste spelade rensad';

  @override
  String get recommendedForYou => 'Rekommenderas för dig';

  @override
  String get remove => 'Ta bort';

  @override
  String get removeFromFolder => 'Remove from folder';

  @override
  String get removeFromLikedPlaylists => 'Ta bort från gillade spellistor';

  @override
  String get removeFromLikedSongs => 'Ta bort från gillade låtar';

  @override
  String get removeFromPlaylist => 'Ta bort från spellistan';

  @override
  String get removeFromRecentlyPlayed => 'Ta bort från senast spelade';

  @override
  String get removeOffline => 'Ta bort från offline';

  @override
  String get removeOfflinePlaylist => 'Ta bort offlinespellista';

  @override
  String get removeOfflinePlaylistConfirm =>
      'Detta tar bort spellistan från offlinelagringen. Låtar som används i andra spellistor kommer fortfarande att vara tillgängliga.';

  @override
  String get removePlaylistQuestion =>
      'Är du säker på att du vill ta bort den här spellistan?';

  @override
  String get removeSearchQueryQuestion =>
      'Är du säker på att du vill ta bort den här sökfrågan?';

  @override
  String get removedFromLikedSongs => 'Removed from liked songs';

  @override
  String get renameSong => 'Rename song';

  @override
  String get repeat => 'Repeat';

  @override
  String get replay => 'Replay';

  @override
  String get restoreError => 'Fel vid återställning av data';

  @override
  String get restoreUserData => 'Återställ användardata';

  @override
  String get restoredSuccess => 'Data har återställts';

  @override
  String get search => 'Sök';

  @override
  String get searchHistoryMsg => 'Sökhistoriken har rensats';

  @override
  String get selectDuration => 'Välj varaktighet';

  @override
  String get setTimer => 'Ställ in timern';

  @override
  String get settingChangedMsg => 'Inställningarna har uppdaterats';

  @override
  String get settings => 'Inställningar';

  @override
  String get share => 'Share';

  @override
  String get shareRecap => 'Share recap';

  @override
  String get shareTimeMachineText => 'My SoundWave recap';

  @override
  String get shuffle => 'Shuffle';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Singles & EPs';

  @override
  String get skipToNext => 'Skip to next';

  @override
  String get skipToPrevious => 'Skip to previous';

  @override
  String get sleepTimer => 'Sleep timer';

  @override
  String get sleepTimerCancelled => 'Insomningstimern avbruten';

  @override
  String get sleepTimerSet => 'Insomningstimern inställd';

  @override
  String get songAdded => 'Låt tillagd';

  @override
  String get songAddedToOffline => 'Låten är nu tillgänglig offline';

  @override
  String get songAlreadyInPlaylist => 'Låten finns redan i spellistan';

  @override
  String get songRemoved => 'Låt borttagen';

  @override
  String get songRemovedFromOffline =>
      'Låten är inte längre tillgänglig offline';

  @override
  String get songs => 'Låtar';

  @override
  String get sponsorBlockDescription =>
      'Skip sponsored segments in supported tracks.';

  @override
  String get sponsorProject => 'Sponsra projektet';

  @override
  String get suggestedArtists => 'Föreslagna artister';

  @override
  String get suggestedPlaylists => 'Föreslagna spellistor';

  @override
  String get tapToView => 'Tap to view';

  @override
  String get themeMode => 'Temaläge';

  @override
  String get themeModeDark => 'Dark';

  @override
  String get themeModeLight => 'Light';

  @override
  String get themeModeSystem => 'System';

  @override
  String get timeMachine => 'Time Machine';

  @override
  String get tools => 'Verktyg';

  @override
  String get topSongs => 'Top songs';

  @override
  String get translate => 'Translate';

  @override
  String get translateDescription =>
      'Help translate SoundWave into your language on Crowdin.';

  @override
  String get understand => 'Jag förstår';

  @override
  String get undo => 'Ångra';

  @override
  String get unpinFromLibrary => 'Unpin from library';

  @override
  String get update => 'Uppdatera';

  @override
  String get useProxy => 'Use proxy';

  @override
  String get useProxyDescription =>
      'Use the proxy only when streaming fails, unnecessary use may break playback.';

  @override
  String get userPlaylists => 'Användarspellistor';

  @override
  String get yes => 'Yes';

  @override
  String get youtubePlaylistLinkOrId => 'Länk eller ID för YouTube-spellista';
}
