// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get about => 'À propos';

  @override
  String get accentChangeMsg => 'Couleur mise à jour avec succès';

  @override
  String get accentColor => 'Couleur';

  @override
  String get add => 'Ajouter';

  @override
  String get addPlaylist => 'Ajouter une playlist';

  @override
  String get addToLikedPlaylists => 'Ajouter aux playlists favorites';

  @override
  String get addToLikedSongs => 'Ajouter aux titres favoris';

  @override
  String get addToPlaylist => 'Ajouter à la playlist';

  @override
  String get addToQueue => 'Ajouter à la file d\'attente';

  @override
  String get addedPlaylists => 'Playlists ajoutées';

  @override
  String get addedSuccess => 'Ajouté avec succès';

  @override
  String get addedToLikedSongs => 'Ajouté aux titres favoris';

  @override
  String get album => 'Album';

  @override
  String get albums => 'Albums';

  @override
  String get allSongs => 'Tous les titres';

  @override
  String get alreadyDownloading => 'Téléchargement en cours';

  @override
  String get annualRecap => 'Récapitulatif annuel';

  @override
  String get appUpdateIsAvailable => 'Mise à jour disponible';

  @override
  String get artist => 'Artiste';

  @override
  String get artistNotFound =>
      'Artiste introuvable. Vérifiez les journaux ou réessayez.';

  @override
  String get artists => 'Artistes';

  @override
  String get audioQuality => 'Qualité audio';

  @override
  String get audioQualityBadge => 'Afficher le badge de qualité audio';

  @override
  String get audioQualityBadgeDescription =>
      'Afficher une petite icône indiquant le débit binaire ou le codec sur la pochette du titre en cours de lecture.';

  @override
  String get audioQualityHigh => 'Élevée';

  @override
  String get audioQualityLow => 'Basse';

  @override
  String get audioQualityMedium => 'Moyenne';

  @override
  String get audioQualityMsg => 'Mise à jour de la qualité audio';

  @override
  String get automaticSongPicker => 'Sélection automatique de titres';

  @override
  String get automaticSongPickerDescription =>
      'Lancer automatiquement un titre aléatoire à la fin de celui en cours.';

  @override
  String get automaticUpdateChecks =>
      'Vérifications de mises à jour automatiques';

  @override
  String get automaticUpdateChecksDescription =>
      'Vérifier automatiquement la disponibilité des mises à jour des applications au démarrage.';

  @override
  String get back => 'Retour';

  @override
  String get backToFavorites => 'Retour aux favoris';

  @override
  String get backedupSuccess => 'Sauvegarde des données effectuée avec succès';

  @override
  String get backupError =>
      'Une erreur s\'est produite lors de la sauvegarde des données';

  @override
  String get backupUserData => 'Sauvegarder les données utilisateur';

  @override
  String get becomeSponsor => 'Devenez sponsor';

  @override
  String get cacheMsg => 'Cache effacé';

  @override
  String get cancel => 'Annuler';

  @override
  String get cancellingDownload => 'Annulation du téléchargement...';

  @override
  String get checkForUpdates => 'Vérifier les mises à jour ?';

  @override
  String get chooseBackupDir => 'Choisissez un dossier de sauvegarde';

  @override
  String get chooseBackupFiles => 'Sélectionnez les fichiers à sauvegarder';

  @override
  String get clear => 'Effacer';

  @override
  String get clearCache => 'Vider le cache';

  @override
  String get clearListeningStats => 'Effacer les statistiques d\'écoute';

  @override
  String get clearListeningStatsQuestion =>
      'Cette opération supprimera les statistiques d\'écoute de la machine à remonter le temps stockées sur cet appareil. Voulez-vous continuer ?';

  @override
  String get clearQueue => 'Vider la file d\'attente';

  @override
  String get clearQueueQuestion =>
      'Êtes-vous sûr de vouloir vider la file d\'attente ?';

  @override
  String get clearRecentlyPlayed => 'Effacer l\'historique de lecture';

  @override
  String get clearRecentlyPlayedQuestion =>
      'Êtes-vous sûr de vouloir effacer l\'historique des titres récemment écoutés ?';

  @override
  String get clearSearchHistory => 'Effacer l\'historique de recherche';

  @override
  String get clearSearchHistoryQuestion =>
      'Êtes-vous sûr de vouloir effacer l\'historique de recherche ?';

  @override
  String get copy => 'Copier';

  @override
  String get confirm => 'Confirmer';

  @override
  String get confirmation => 'Confirmation';

  @override
  String get copyLogs => 'Copier les journaux';

  @override
  String get copyLogsNoLogs => 'Aucun journal à copier';

  @override
  String get copyLogsSuccess => 'Journaux copiés avec succès';

  @override
  String get create => 'Créer';

  @override
  String get createFolder => 'Créer un dossier';

  @override
  String get custom => 'Personnalisé';

  @override
  String get customPlaylistImgUrl =>
      'URL de l\'image de la playlist personnalisée';

  @override
  String get customPlaylistName => 'Nom de la playlist personnalisée';

  @override
  String get customPlaylists => 'Playlists personnalisées';

  @override
  String get dateAdded => 'Date d\'ajout';

  @override
  String get default_ => 'Par défaut';

  @override
  String get delete => 'Supprimer';

  @override
  String get deleteDownloads => 'Supprimer les fichiers téléchargés';

  @override
  String get deleteDownloadsQuestion =>
      'Êtes-vous sûr de vouloir supprimer tous les fichiers téléchargés ?';

  @override
  String get deleteFolder => 'Supprimer le dossier';

  @override
  String get deleteFolderQuestion =>
      'Êtes-vous sûr de vouloir supprimer ce dossier ? Les playlists qu\'il contient seront déplacées vers la bibliothèque principale.';

  @override
  String get deletePlaylist => 'Supprimer la playlist';

  @override
  String get download => 'Télécharger';

  @override
  String get downloadAppUpdate =>
      'Télécharger la mise à jour de l\'application';

  @override
  String get downloadCancelled => 'Téléchargement annulé';

  @override
  String get downloadFailed => 'Échec du téléchargement';

  @override
  String get downloadPlaylist => 'Télécharger la playlist';

  @override
  String get downloadsDeleted => 'Téléchargements supprimés avec succès';

  @override
  String get dynamicColor =>
      'Couleur d\'accentuation dynamique (Android 12 et versions ultérieures)';

  @override
  String get dynamicColorDescription =>
      'Utilisez les couleurs d\'accentuation de votre thème système Android.';

  @override
  String get editFolder => 'Modifier le dossier';

  @override
  String get editPlaylist => 'Modifier la playlist';

  @override
  String get emptyFolderMsg =>
      'Ce dossier est vide. Ajoutez des playlists pour organiser votre musique.';

  @override
  String get enableUpdateChecksDescription =>
      'Souhaitez-vous que SoundWave vérifie automatiquement la présence de mises à jour à partir des versions publiées sur GitHub ? Vous pouvez à tout moment vérifier manuellement la présence de mises à jour depuis les paramètres.';

  @override
  String get endOfSong => 'Fin du titre';

  @override
  String get enterFolderName => 'Veuillez saisir un nom de dossier';

  @override
  String get equalizer => 'Égaliseur';

  @override
  String get equalizerAndroidOnly =>
      'L\'égaliseur est uniquement disponible sur Android.';

  @override
  String get equalizerBands => 'Bandes';

  @override
  String get equalizerDisabledHint =>
      'Les réglages de gain de bande sont désactivés.';

  @override
  String get equalizerEnable => 'Activer l\'égaliseur';

  @override
  String get equalizerEnabledHint =>
      'Les réglages de gain de bande sont activés.';

  @override
  String get equalizerInitFailed =>
      'L\'égaliseur n\'a pas pu être initialisé pour le moment. Essayez de lancer un titre et rouvrez cette page.';

  @override
  String get equalizerPresetBalanced => 'Équilibré';

  @override
  String get equalizerPresetBassBoost => 'Amplification des basses';

  @override
  String get equalizerPresetElectronic => 'Électronique';

  @override
  String get equalizerPresetPop => 'Pop';

  @override
  String get equalizerPresetRock => 'Rock';

  @override
  String get equalizerPresetTrebleBoost => 'Amplification des aigus';

  @override
  String get equalizerPresetVocal => 'Vocal';

  @override
  String get equalizerPresets => 'Préréglages';

  @override
  String get equalizerResetBands => 'Réinitialiser les bandes';

  @override
  String get error =>
      'Une erreur s\'est produite. Vérifiez les journaux ou réessayez.';

  @override
  String get externalRecommendations => 'Recommandations externes';

  @override
  String get externalRecommendationsDescription =>
      'Utilisez l\'algorithme externe pour les recommandations plutôt que celui de SoundWave.';

  @override
  String get failedPlayingRadio => 'Impossible de lire la station de radio';

  @override
  String get failedToLoadPlaylist => 'Impossible de charger la playlist';

  @override
  String get fieldsNotEmpty => 'Tous les champs doivent être remplis';

  @override
  String get folderAlreadyExists => 'Un dossier portant ce nom existe déjà';

  @override
  String get folderDeleted => 'Dossier supprimé avec succès';

  @override
  String get folderName => 'Nom du dossier';

  @override
  String get folderUpdated => 'Dossier mis à jour avec succès';

  @override
  String get goToArtist => 'Aller à la page de l\'artiste';

  @override
  String get home => 'Accueil';

  @override
  String get hours => 'Heures';

  @override
  String get imagePicked => 'Image sélectionnée';

  @override
  String get importSpotifyPlaylist => 'Importer une playlist depuis Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Importer une playlist Spotify';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Exportez votre playlist Spotify au format CSV sur chosic.com/spotify-playlist-exporter/, puis sélectionnez le fichier ou collez son contenu ci-dessous. SoundWave recherchera chaque titre sur YouTube.';

  @override
  String get chooseCsvFile => 'Choisissez un fichier CSV';

  @override
  String get openChosicExporter => 'Ouvrir l\'exportateur Chosic pour Spotify';

  @override
  String get pasteCsv => 'Coller un fichier CSV';

  @override
  String get playlistName => 'Nom de la playlist';

  @override
  String get importPlaylist => 'Importer une playlist';

  @override
  String get spotifyCsvHint => 'Collez ici le contenu du fichier CSV';

  @override
  String get spotifyPlaylistNameHint => 'Playlist Spotify importée';

  @override
  String get spotifyPlaylistEmpty =>
      'Commencez par sélectionner un fichier CSV ou collez le contenu d\'un fichier CSV';

  @override
  String get enterPlaylistName => 'Veuillez saisir un nom pour la playlist';

  @override
  String get spotifyPlaylistInvalid =>
      'Le fichier CSV ne contient pas de colonnes « Titre » et « Artiste »';

  @override
  String get spotifyPlaylistImporting => 'Importation de la playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found sur $total de titres importés';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Recherche $done sur $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'Une importation est déjà en cours';

  @override
  String get spotifyPlaylistMissingSongs => 'Titres introuvables';

  @override
  String get spotifyPlaylistImportFailed =>
      'Échec de l\'importation de la playlist';

  @override
  String get invalidYouTubePlaylist => 'Playlist YouTube invalide';

  @override
  String get language => 'Langue';

  @override
  String get languageDe => 'Allemand';

  @override
  String get languageEl => 'Grec';

  @override
  String get languageEn => 'Anglais';

  @override
  String get languageEs => 'Espagnol';

  @override
  String get languageEt => 'Estonien';

  @override
  String get languageFr => 'Français';

  @override
  String get languageHe => 'Hébreu';

  @override
  String get languageHi => 'Hindi';

  @override
  String get languageHu => 'Hongrois';

  @override
  String get languageId => 'Indonésien';

  @override
  String get languageIt => 'Italien';

  @override
  String get languageJa => 'Japonais';

  @override
  String get languageKo => 'Coréen';

  @override
  String get languageMsg => 'Langue mise à jour avec succès';

  @override
  String get languagePl => 'Polonais';

  @override
  String get languagePt => 'Portugais';

  @override
  String get languageRu => 'Russe';

  @override
  String get languageSv => 'Suédois';

  @override
  String get languageTa => 'Tamoul';

  @override
  String get languageTr => 'Turc';

  @override
  String get languageUk => 'Ukrainien';

  @override
  String get languageZh => 'Chinois (Simplifié)';

  @override
  String get languageZhHant => 'Chinois (Traditionnel)';

  @override
  String get library => 'Bibliothèque';

  @override
  String get licenses => 'Licences';

  @override
  String get likedPlaylists => 'Playlists favorites';

  @override
  String get likedSongs => 'Titres favoris';

  @override
  String get linkCopied => 'Lien vers la playlist copié dans le presse-papiers';

  @override
  String get listeningStats => 'Statistiques d\'écoute';

  @override
  String get listeningStatsCleared => 'Statistiques d\'écoute effacées';

  @override
  String get listeningStatsDescription =>
      'Suivez les statistiques d\'écoute locales pour obtenir des bilans mensuels et annuels.';

  @override
  String get loading => 'Chargement';

  @override
  String get lyrics => 'Paroles';

  @override
  String get lyricsNotAvailable => 'Paroles non disponibles';

  @override
  String get makeOffline => 'Rendre disponible hors ligne';

  @override
  String get minutes => 'Minutes';

  @override
  String get minutesListened => 'minutes écoutées';

  @override
  String get monthlyListeners => 'auditeurs mensuels';

  @override
  String get moreOptions => 'Plus d\'options';

  @override
  String get mostPlayed => 'Les plus écoutés';

  @override
  String get moveToFolder => 'Déplacer vers le dossier';

  @override
  String get name => 'Nom';

  @override
  String get newAnnouncement => 'Nouvelle annonce publiée';

  @override
  String get newFolder => 'Nouveau dossier';

  @override
  String get no => 'Non';

  @override
  String get noCustomPlaylists =>
      'Aucune playlist personnalisée n\'a encore été créée';

  @override
  String get noFolders => 'Aucun dossier n\'a encore été créé';

  @override
  String get noListeningStats =>
      'Aucune statistique d\'écoute n\'est encore disponible';

  @override
  String get noOfflineLibraryContent =>
      'Aucun contenu hors ligne. Activez le mode en ligne ou téléchargez des playlists ou des titres pour utiliser la bibliothèque.';

  @override
  String get noPlaylistsAdded => 'Aucune playlist n\'a encore été ajoutée';

  @override
  String get noRadioStations => 'Aucune station de radio disponible';

  @override
  String get noSongsInPlaylist => 'Aucun titre dans la playlist';

  @override
  String get noSongsInQueue => 'Aucun titre dans la file d\'attente';

  @override
  String get notYTlist => 'Identifiant de playlist YouTube non valide';

  @override
  String get offlineMode => 'Mode hors ligne';

  @override
  String get offlineModeDescription =>
      'Désactivez les fonctionnalités en ligne et utilisez SoundWave complètement hors ligne.';

  @override
  String get offlinePlaylists => 'Playlists hors ligne';

  @override
  String get offlineSongs => 'Titres hors ligne';

  @override
  String get others => 'Autres';

  @override
  String get pause => 'Pause';

  @override
  String get pickImageFromDevice => 'Sélectionner une image sur l\'appareil';

  @override
  String get pinToLibrary => 'Épingler à la bibliothèque';

  @override
  String get pinnedPlaylists => 'Épinglées';

  @override
  String get pinnedPlaylistsLimit =>
      'Vous pouvez épingler jusqu\'à 5 playlists ou albums';

  @override
  String get play => 'Lecture';

  @override
  String get playNext => 'Lire ensuite';

  @override
  String get playlist => 'Playlist';

  @override
  String get playlistAlreadyDownloaded => 'Playlist déjà téléchargée';

  @override
  String get playlistAlreadyExists => 'La playlist existe déjà';

  @override
  String get playlistDownloaded => 'Playlist téléchargée';

  @override
  String get playlistEmpty => 'La playlist est vide';

  @override
  String get playlistFolders => 'Dossiers de playlists';

  @override
  String get playlistRemovedFromOffline =>
      'Playlist supprimée du stockage hors ligne';

  @override
  String get playlistUpdated => 'Playlist mise à jour avec succès';

  @override
  String get playlists => 'Playlists';

  @override
  String get preferences => 'Préférences';

  @override
  String get provideIdOrNameError =>
      'Veuillez indiquer un identifiant YouTube ou le nom d\'une playlist personnalisée';

  @override
  String get pureBlackTheme => 'Thème sombre';

  @override
  String get pureBlackThemeDescription =>
      'Utilisez un fond noir pur en mode sombre pour les écrans OLED.';

  @override
  String get queue => 'File d\'attente';

  @override
  String get radioStations => 'Stations de Radio';

  @override
  String get recentlyPlayed => 'Lectures récentes';

  @override
  String get recentlyPlayedMsg => 'Historique de lecture effacé';

  @override
  String get recommendedForYou => 'Recommandations';

  @override
  String get remove => 'Supprimer';

  @override
  String get removeFromFolder => 'Supprimer du dossier';

  @override
  String get removeFromLikedPlaylists => 'Supprimer des playlists favorites';

  @override
  String get removeFromLikedSongs => 'Supprimer des titres favoris';

  @override
  String get removeFromPlaylist => 'Supprimer de la playlist';

  @override
  String get removeFromRecentlyPlayed => 'Supprimer des lectures récentes';

  @override
  String get removeOffline => 'Supprimer du mode hors ligne';

  @override
  String get removeOfflinePlaylist => 'Supprimer la playlist hors ligne';

  @override
  String get removeOfflinePlaylistConfirm =>
      'Cette opération supprimera la playlist de l\'espace de stockage hors ligne. Les titres figurant dans d\'autres playlists resteront disponibles.';

  @override
  String get removePlaylistQuestion =>
      'Êtes-vous sûr de vouloir supprimer cette playlist ?';

  @override
  String get removeSearchQueryQuestion =>
      'Êtes-vous sûr de vouloir supprimer cette requête de recherche ?';

  @override
  String get removedFromLikedSongs => 'Retiré des titres favoris';

  @override
  String get renameSong => 'Renommer le titre';

  @override
  String get repeat => 'Répéter';

  @override
  String get replay => 'Rejouer';

  @override
  String get restoreError => 'Erreur lors de la restauration des données';

  @override
  String get restoreUserData => 'Restaurer les données utilisateur';

  @override
  String get restoredSuccess => 'Données restaurées avec succès';

  @override
  String get search => 'Rechercher';

  @override
  String get searchHistoryMsg => 'Historique de recherche effacé';

  @override
  String get selectDuration => 'Sélectionner la durée';

  @override
  String get setTimer => 'Régler la minuterie';

  @override
  String get settingChangedMsg => 'Paramètre mis à jour avec succès';

  @override
  String get settings => 'Paramètres';

  @override
  String get share => 'Partager';

  @override
  String get shareRecap => 'Partager le récapitulatif';

  @override
  String get shareTimeMachineText => 'Mon récapitulatif SoundWave';

  @override
  String get shuffle => 'Lecture aléatoire';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Singles & EPs';

  @override
  String get skipToNext => 'Passer au suivant';

  @override
  String get skipToPrevious => 'Revenir au précédent';

  @override
  String get sleepTimer => 'Minuterie de veille';

  @override
  String get sleepTimerCancelled => 'Minuterie de veille annulée';

  @override
  String get sleepTimerSet => 'Minuterie de veille réglée';

  @override
  String get songAdded => 'Titre ajouté avec succès';

  @override
  String get songAddedToOffline =>
      'Le titre est désormais disponible hors ligne';

  @override
  String get songAlreadyInPlaylist => 'Ce titre figure déjà dans la playlist';

  @override
  String get songRemoved => 'Titre supprimé avec succès';

  @override
  String get songRemovedFromOffline =>
      'Le titre n\'est plus disponible hors ligne';

  @override
  String get songs => 'Titres';

  @override
  String get sponsorBlockDescription =>
      'Ignorer les segments sponsorisés dans les titres pris en charge.';

  @override
  String get sponsorProject => 'Financer le projet';

  @override
  String get suggestedArtists => 'Artistes recommandés';

  @override
  String get suggestedPlaylists => 'Playlists recommandées';

  @override
  String get tapToView => 'Appuyez pour afficher';

  @override
  String get themeMode => 'Mode de thème';

  @override
  String get themeModeDark => 'Sombre';

  @override
  String get themeModeLight => 'Clair';

  @override
  String get themeModeSystem => 'Système';

  @override
  String get timeMachine => 'Machine à remonter le temps';

  @override
  String get tools => 'Outils';

  @override
  String get topSongs => 'Meilleurs titres';

  @override
  String get translate => 'Traduire';

  @override
  String get translateDescription =>
      'Contribuez à la traduction de SoundWave dans votre langue sur Crowdin.';

  @override
  String get understand => 'Je comprends';

  @override
  String get undo => 'Annuler';

  @override
  String get unpinFromLibrary => 'Détacher de la bibliothèque';

  @override
  String get update => 'Mise à jour';

  @override
  String get useProxy => 'Utiliser un proxy';

  @override
  String get useProxyDescription =>
      'N\'utilisez le proxy qu\'en cas d\'échec de la diffusion en continu ; une utilisation inutile pourrait perturber la lecture.';

  @override
  String get userPlaylists => 'Playlists des Utilisateurs';

  @override
  String get yes => 'Oui';

  @override
  String get youtubePlaylistLinkOrId =>
      'Lien ou identifiant d\'une playlist YouTube';
}
