// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Modern Greek (`el`).
class AppLocalizationsEl extends AppLocalizations {
  AppLocalizationsEl([String locale = 'el']) : super(locale);

  @override
  String get about => 'Σχετικά';

  @override
  String get accentChangeMsg => 'Το χρώμα έμφασης έχει αλλάξει';

  @override
  String get accentColor => 'Χρώμα έμφασης';

  @override
  String get add => 'Προσθήκη';

  @override
  String get addPlaylist => 'Προσθήκη λίστας αναπαραγωγής';

  @override
  String get addToLikedPlaylists =>
      'Προσθήκη στις λίστες αναπαραγωγής που αρέσουν';

  @override
  String get addToLikedSongs => 'Προσθήκη στα αγαπημένα τραγούδια';

  @override
  String get addToPlaylist => 'Προσθήκη στη λίστα αναπαραγωγής';

  @override
  String get addToQueue => 'Add to queue';

  @override
  String get addedPlaylists => 'Προστέθηκαν λίστες αναπαραγωγής';

  @override
  String get addedSuccess => 'Επιτυχής προσθήκη';

  @override
  String get addedToLikedSongs => 'Προσθήκη στα αγαπημένα τραγούδια';

  @override
  String get album => 'Άλμπουμ';

  @override
  String get albums => 'Άλμπουμ';

  @override
  String get allSongs => 'All songs';

  @override
  String get alreadyDownloading => 'Ήδη λήψη';

  @override
  String get annualRecap => 'Annual recap';

  @override
  String get appUpdateIsAvailable =>
      'Υπάρχει διαθέσιμη ενημέρωση για την εφαρμογή';

  @override
  String get artist => 'Καλλιτέχνης';

  @override
  String get artistNotFound => 'Artist not found. Check logs or try again.';

  @override
  String get artists => 'Artists';

  @override
  String get audioQuality => 'Ποιότητα ήχου';

  @override
  String get audioQualityBadge => 'Show audio quality badge';

  @override
  String get audioQualityBadgeDescription =>
      'Display a small bitrate/codec badge on the now playing artwork.';

  @override
  String get audioQualityHigh => 'Υψηλή';

  @override
  String get audioQualityLow => 'Χαμηλή';

  @override
  String get audioQualityMedium => 'Μεσαίο';

  @override
  String get audioQualityMsg => 'Η ποιότητα ήχου έχει αλλάξει';

  @override
  String get automaticSongPicker => 'Αυτόματος επιλογέας τραγουδιού';

  @override
  String get automaticSongPickerDescription =>
      'Αυτόματη αναπαραγωγή ενός τυχαίου τραγουδιού μετά το τέλος του τρέχοντος κομματιού.';

  @override
  String get automaticUpdateChecks => 'Αυτόματοι έλεγχοι ενημέρωσης';

  @override
  String get automaticUpdateChecksDescription =>
      'Αυτόματος έλεγχος ενημέρωσης της εφαρμογής κατά την εκκίνηση.';

  @override
  String get back => 'Back';

  @override
  String get backToFavorites => 'Επιστροφή στα αγαπημένα';

  @override
  String get backedupSuccess => 'Επιτυχής δημιουργία αντιγράφου ασφαλείας';

  @override
  String get backupError =>
      'Σφάλμα κατά τη δημιουργία αντιγράφου ασφαλείας δεδομένων';

  @override
  String get backupUserData =>
      'Δημιουργία αντιγράφων ασφαλείας δεδομένων χρήστη';

  @override
  String get becomeSponsor => 'Γίνετε χορηγός';

  @override
  String get cacheMsg => 'Έγινε εκκαθάριση της βραχύχρονης μνήμης';

  @override
  String get cancel => 'Ακύρωση';

  @override
  String get cancellingDownload => 'Cancelling download...';

  @override
  String get checkForUpdates => 'Έλεγχος για ενημερώσεις;';

  @override
  String get chooseBackupDir => 'Επιλογή καταλόγου αντιγράφων ασφαλείας';

  @override
  String get chooseBackupFiles => 'Επιλογή αρχείων για αντίγραφα ασφαλείας';

  @override
  String get clear => 'Απαλοιφή';

  @override
  String get clearCache => 'Απαλοιφή βραχύχρονης μνήμης';

  @override
  String get clearListeningStats => 'Clear listening stats';

  @override
  String get clearListeningStatsQuestion =>
      'This will delete Time Machine listening stats stored on this device. Continue?';

  @override
  String get clearQueue => 'Εκκαθάριση λίστας';

  @override
  String get clearQueueQuestion => 'Are you sure you want to clear the queue?';

  @override
  String get clearRecentlyPlayed =>
      'Καθαρισμός πρόσφατου ιστορικού αναπαραγωγής';

  @override
  String get clearRecentlyPlayedQuestion =>
      'Καθαρισμός πρόσφατου ιστορικού αναπαραγωγής;';

  @override
  String get clearSearchHistory => 'Καθαρισμός ιστορικού αναζήτησης';

  @override
  String get clearSearchHistoryQuestion => 'Καθαρισμός ιστορικού αναζήτησης?';

  @override
  String get copy => 'Copy';

  @override
  String get confirm => 'Επιβεβαίωση';

  @override
  String get confirmation => 'Επιβεβαίωση';

  @override
  String get copyLogs => 'Αντιγραφή καταγραφών';

  @override
  String get copyLogsNoLogs => 'Δεν βρέθηκαν καταγραφές για αντιγραφή';

  @override
  String get copyLogsSuccess => 'Οι καταγραφές αντιγράφηκαν με επιτυχία.';

  @override
  String get create => 'Δημιουργία';

  @override
  String get createFolder => 'Δημιουργία φακέλου';

  @override
  String get custom => 'Προτιμητέο';

  @override
  String get customPlaylistImgUrl =>
      'Σύνδεσμος εικόνας προσαρμοσμένης λίστας αναπαραγωγής';

  @override
  String get customPlaylistName => 'Όνομα προσαρμοσμένης λίστας αναπαραγωγής';

  @override
  String get customPlaylists => 'Προσαρμοσμένα λίστες αναπαραγωγής';

  @override
  String get dateAdded => 'Ημερομηνία Προσθήκης';

  @override
  String get default_ => 'Προεπιλογή';

  @override
  String get delete => 'Διαγραφή';

  @override
  String get deleteDownloads => 'Delete downloads';

  @override
  String get deleteDownloadsQuestion =>
      'Are you sure you want to delete all downloads?';

  @override
  String get deleteFolder => 'Διαγραφή φακέλου';

  @override
  String get deleteFolderQuestion =>
      'Είστε βέβαιοι ότι θέλετε να διαγράψετε αυτό το φάκελο? Οι λίστες αναπαραγωγής μέσα θα μετακινηθούν στην κύρια βιβλιοθήκη.';

  @override
  String get deletePlaylist => 'Διαγραφή λίστας αναπαραγωγής';

  @override
  String get download => 'Λήψη';

  @override
  String get downloadAppUpdate => 'Λήψη ενημέρωσης εφαρμογής';

  @override
  String get downloadCancelled => 'Η λήψη ακυρώθηκε';

  @override
  String get downloadFailed => 'Αποτυχία λήψης';

  @override
  String get downloadPlaylist => 'Λήψη λίστας αναπαραγωγής';

  @override
  String get downloadsDeleted => 'Downloads deleted successfully';

  @override
  String get dynamicColor => 'Δυναμικό χρώμα έμφασης (Android 12+)';

  @override
  String get dynamicColorDescription =>
      'Use the accent colors from your Android system theme.';

  @override
  String get editFolder => 'Edit folder';

  @override
  String get editPlaylist => 'Επεξεργασία λίστας αναπαραγωγής';

  @override
  String get emptyFolderMsg =>
      'Αυτός ο φάκελος είναι κενός. Προσθέστε λίστες αναπαραγωγής για να οργανώσετε τη μουσική σας.';

  @override
  String get enableUpdateChecksDescription =>
      'Θα θέλατε το SoundWave να ελέγχει για ενημερώσεις αυτόματα από τις εκδόσεις του GitHub? Μπορείτε πάντα να ελέγξετε για ενημερώσεις χειροκίνητα από τις ρυθμίσεις';

  @override
  String get endOfSong => 'Τέλος τραγουδιού';

  @override
  String get enterFolderName => 'Παρακαλώ εισάγετε ένα όνομα φακέλου';

  @override
  String get equalizer => 'Equalizer';

  @override
  String get equalizerAndroidOnly => 'Equalizer is available on Android only.';

  @override
  String get equalizerBands => 'Bands';

  @override
  String get equalizerDisabledHint => 'Band gain adjustments are bypassed.';

  @override
  String get equalizerEnable => 'Enable equalizer';

  @override
  String get equalizerEnabledHint => 'Band gain adjustments are active.';

  @override
  String get equalizerInitFailed =>
      'Equalizer could not be initialized right now. Try playing a song and reopen this page.';

  @override
  String get equalizerPresetBalanced => 'Balanced';

  @override
  String get equalizerPresetBassBoost => 'Bass Boost';

  @override
  String get equalizerPresetElectronic => 'Electronic';

  @override
  String get equalizerPresetPop => 'Pop';

  @override
  String get equalizerPresetRock => 'Rock';

  @override
  String get equalizerPresetTrebleBoost => 'Treble Boost';

  @override
  String get equalizerPresetVocal => 'Vocal';

  @override
  String get equalizerPresets => 'Presets';

  @override
  String get equalizerResetBands => 'Reset bands';

  @override
  String get error => 'Παρουσιάστηκε κάποιο πρόβλημα';

  @override
  String get externalRecommendations => 'Εξωτερικές συστάσεις';

  @override
  String get externalRecommendationsDescription =>
      'Χρήση εξωτερικού αλγόριθμου για συστάσεις αντί της εφαρμογής.';

  @override
  String get failedPlayingRadio => 'Failed to play radio station';

  @override
  String get failedToLoadPlaylist => 'Failed to load playlist';

  @override
  String get fieldsNotEmpty => 'Όλα τα πεδία πρέπει να συμπληρωθούν';

  @override
  String get folderAlreadyExists => 'Υπάρχει ήδη ένας φάκελος με αυτό το όνομα';

  @override
  String get folderDeleted => 'Ο φάκελος διαγράφηκε επιτυχώς';

  @override
  String get folderName => 'Όνομα φακέλου';

  @override
  String get folderUpdated => 'Folder updated successfully';

  @override
  String get goToArtist => 'Go to artist';

  @override
  String get home => 'Κεντρική';

  @override
  String get hours => 'Ώρες';

  @override
  String get imagePicked => 'Επιλέχθηκε εικόνα';

  @override
  String get importSpotifyPlaylist => 'Import playlist from Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Import Spotify playlist';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Export your Spotify playlist as CSV at chosic.com/spotify-playlist-exporter/, then choose the file or paste its contents below. SoundWave will search YouTube for each song.';

  @override
  String get chooseCsvFile => 'Choose CSV file';

  @override
  String get openChosicExporter => 'Open Chosic Spotify exporter';

  @override
  String get pasteCsv => 'Paste CSV';

  @override
  String get playlistName => 'Playlist name';

  @override
  String get importPlaylist => 'Import playlist';

  @override
  String get spotifyCsvHint => 'Paste CSV content here';

  @override
  String get spotifyPlaylistNameHint => 'Imported Spotify playlist';

  @override
  String get spotifyPlaylistEmpty =>
      'Choose a CSV file or paste CSV content first';

  @override
  String get enterPlaylistName => 'Please enter a playlist name';

  @override
  String get spotifyPlaylistInvalid =>
      'The CSV does not contain Song and Artist columns';

  @override
  String get spotifyPlaylistImporting => 'Importing playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found of $total songs imported';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Searching $done of $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'An import is already in progress';

  @override
  String get spotifyPlaylistMissingSongs => 'Songs not found';

  @override
  String get spotifyPlaylistImportFailed => 'Playlist import failed';

  @override
  String get invalidYouTubePlaylist => 'Invalid Youtube playlist';

  @override
  String get language => 'Γλώσσα';

  @override
  String get languageDe => 'German';

  @override
  String get languageEl => 'Greek';

  @override
  String get languageEn => 'English';

  @override
  String get languageEs => 'Spanish';

  @override
  String get languageEt => 'Estonian';

  @override
  String get languageFr => 'French';

  @override
  String get languageHe => 'Hebrew';

  @override
  String get languageHi => 'Hindi';

  @override
  String get languageHu => 'Hungarian';

  @override
  String get languageId => 'Indonesian';

  @override
  String get languageIt => 'Italian';

  @override
  String get languageJa => 'Japanese';

  @override
  String get languageKo => 'Korean';

  @override
  String get languageMsg => 'Η γλώσσα έχει αλλάξει';

  @override
  String get languagePl => 'Polish';

  @override
  String get languagePt => 'Portuguese';

  @override
  String get languageRu => 'Russian';

  @override
  String get languageSv => 'Swedish';

  @override
  String get languageTa => 'Tamil';

  @override
  String get languageTr => 'Turkish';

  @override
  String get languageUk => 'Ukrainian';

  @override
  String get languageZh => 'Chinese (Simplified)';

  @override
  String get languageZhHant => 'Chinese (Traditional)';

  @override
  String get library => 'Βιβλιοθήκη';

  @override
  String get licenses => 'Άδειες';

  @override
  String get likedPlaylists => 'Λίστες αγαπημένων';

  @override
  String get likedSongs => 'Αγαπημένα τραγούδια';

  @override
  String get linkCopied => 'Playlist link copied to clipboard';

  @override
  String get listeningStats => 'Listening stats';

  @override
  String get listeningStatsCleared => 'Listening stats cleared';

  @override
  String get listeningStatsDescription =>
      'Track local listening stats for monthly and yearly recaps.';

  @override
  String get loading => 'Loading';

  @override
  String get lyrics => 'Στίχοι';

  @override
  String get lyricsNotAvailable => 'Δεν υπάρχουν διαθέσιμοι στίχοι';

  @override
  String get makeOffline => 'Διαθέσιμα εκτός σύνδεσης';

  @override
  String get minutes => 'Λεπτά';

  @override
  String get minutesListened => 'minutes listened';

  @override
  String get monthlyListeners => 'monthly listeners';

  @override
  String get moreOptions => 'More options';

  @override
  String get mostPlayed => 'Most played';

  @override
  String get moveToFolder => 'Μετακίνηση στο φάκελο';

  @override
  String get name => 'Όνομα';

  @override
  String get newAnnouncement => 'Νέα ανακοίνωση δημοσιεύτηκε';

  @override
  String get newFolder => 'Νέος φάκελος';

  @override
  String get no => 'Όχι';

  @override
  String get noCustomPlaylists =>
      'Δεν έχετε δημιουργήσει ακόμα λίστες αναπαραγωγής';

  @override
  String get noFolders => 'No folders created yet';

  @override
  String get noListeningStats => 'No listening stats yet';

  @override
  String get noOfflineLibraryContent =>
      'No offline content. Enable online mode or download playlists/songs to use the library.';

  @override
  String get noPlaylistsAdded =>
      'Δεν έχουν προστεθεί λίστες αναπαραγωγής ακόμα';

  @override
  String get noRadioStations => 'No radio stations available';

  @override
  String get noSongsInPlaylist => 'No songs in playlist';

  @override
  String get noSongsInQueue => 'Δεν υπάρχουν τραγούδια σε ουρά';

  @override
  String get notYTlist =>
      'Αυτό δεν είναι αναγνωριστικό λίστας αναπαραγωγής του YouTube';

  @override
  String get offlineMode => 'Λειτουργία εκτός σύνδεσης';

  @override
  String get offlineModeDescription =>
      'Disable online features and use SoundWave completely offline.';

  @override
  String get offlinePlaylists => 'Λίστες αναπαραγωγής εκτός σύνδεσης';

  @override
  String get offlineSongs => 'Τραγούδια εκτός σύνδεσης';

  @override
  String get others => 'Άλλα';

  @override
  String get pause => 'Pause';

  @override
  String get pickImageFromDevice => 'Επιλέξτε εικόνα από τη συσκευή';

  @override
  String get pinToLibrary => 'Pin to library';

  @override
  String get pinnedPlaylists => 'Pinned';

  @override
  String get pinnedPlaylistsLimit => 'You can pin up to 5 playlists or albums';

  @override
  String get play => 'Play';

  @override
  String get playNext => 'Αναπαραγωγή επόμενου';

  @override
  String get playlist => 'Λίστα αναπαραγωγής';

  @override
  String get playlistAlreadyDownloaded =>
      'Η λίστα αναπαραγωγής έχει ήδη ληφθεί';

  @override
  String get playlistAlreadyExists => 'Η λίστα αναπαραγωγής υπάρχει ήδη';

  @override
  String get playlistDownloaded => 'Λήψη λίστας αναπαραγωγής';

  @override
  String get playlistEmpty => 'Η λίστα είναι κενή';

  @override
  String get playlistFolders => 'Φάκελοι λίστας αναπαραγωγής';

  @override
  String get playlistRemovedFromOffline =>
      'Η λίστα αναπαραγωγής αφαιρέθηκε από αποσυνδεδεμένο χώρο';

  @override
  String get playlistUpdated => 'Η λίστα αναπαραγωγής ενημερώθηκε επιτυχώς';

  @override
  String get playlists => 'Λίστες αναπαραγωγής';

  @override
  String get preferences => 'Ρυθμίσεις';

  @override
  String get provideIdOrNameError =>
      'Παρακαλώ παρέχετε είτε αναγνωριστικό YouTube είτε όνομα προσαρμοσμένης λίστας αναπαραγωγής';

  @override
  String get pureBlackTheme => 'Καθαρό μαύρο θέμα';

  @override
  String get pureBlackThemeDescription =>
      'Use a true black background in dark mode for OLED displays.';

  @override
  String get queue => 'Λίστα';

  @override
  String get radioStations => 'Radio Stations';

  @override
  String get recentlyPlayed => 'Πρόσφατα εκτελεσμένα';

  @override
  String get recentlyPlayedMsg =>
      'Το ιστορικό αναπαραγωγής διαγράφηκε πρόσφατα';

  @override
  String get recommendedForYou => 'Συνιστάται για εσάς';

  @override
  String get remove => 'Αφαίρεση';

  @override
  String get removeFromFolder => 'Αφαίρεση από το φάκελο';

  @override
  String get removeFromLikedPlaylists =>
      'Κατάργηση από τις λίστες αναπαραγωγής που αρέσουν';

  @override
  String get removeFromLikedSongs => 'Αφαίρεση από αγαπημένα τραγούδια';

  @override
  String get removeFromPlaylist => 'Αφαίρεση από τη λίστα αναπαραγωγής';

  @override
  String get removeFromRecentlyPlayed => 'Κατάργηση από τα πρόσφατα παιγμένα';

  @override
  String get removeOffline => 'Αφαίρεση από αποσυνδεδεμένο';

  @override
  String get removeOfflinePlaylist =>
      'Αφαίρεση Λίστας Αναπαραγωγής Χωρίς Σύνδεση';

  @override
  String get removeOfflinePlaylistConfirm =>
      'Αυτό θα αφαιρέσει τη λίστα αναπαραγωγής από τον χώρο αποθήκευσης εκτός σύνδεσης. Τραγούδια που χρησιμοποιούνται σε άλλες λίστες αναπαραγωγής θα είναι ακόμα διαθέσιμα.';

  @override
  String get removePlaylistQuestion =>
      'Κατάργηση αυτής της λίστας αναπαραγωγής;';

  @override
  String get removeSearchQueryQuestion =>
      'Να καταργηθεί αυτό το ερώτημα αναζήτησης;';

  @override
  String get removedFromLikedSongs => 'Διαγραφή από αγαπημένα τραγούδια';

  @override
  String get renameSong => 'Μετονομασία τραγουδιού';

  @override
  String get repeat => 'Repeat';

  @override
  String get replay => 'Replay';

  @override
  String get restoreError => 'Σφάλμα κατά την επαναφορά δεδομένων';

  @override
  String get restoreUserData => 'Επαναφορά δεδομένων χρήστη';

  @override
  String get restoredSuccess => 'Η επαναφορά ολοκληρώθηκε με επιτυχία';

  @override
  String get search => 'Αναζήτηση';

  @override
  String get searchHistoryMsg => 'Έγινε απαλοιφή του ιστορικού αναζήτησης';

  @override
  String get selectDuration => 'Επιλογή διάρκειας';

  @override
  String get setTimer => 'Ορισμός χρονομέτρου';

  @override
  String get settingChangedMsg => 'Η ρύθμιση άλλαξε';

  @override
  String get settings => 'Ρυθμίσεις';

  @override
  String get share => 'Share';

  @override
  String get shareRecap => 'Share recap';

  @override
  String get shareTimeMachineText => 'My SoundWave recap';

  @override
  String get shuffle => 'Shuffle';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Singles & EPs';

  @override
  String get skipToNext => 'Skip to next';

  @override
  String get skipToPrevious => 'Skip to previous';

  @override
  String get sleepTimer => 'Sleep timer';

  @override
  String get sleepTimerCancelled => 'Ο χρονοδιακόπτης ύπνου ακυρώθηκε';

  @override
  String get sleepTimerSet => 'Ρύθμιση χρονοδιακόπτη ύπνου';

  @override
  String get songAdded => 'Το τραγούδι προστέθηκε με επιτυχία!';

  @override
  String get songAddedToOffline =>
      'Το τραγούδι είναι τώρα διαθέσιμο εκτός σύνδεσης';

  @override
  String get songAlreadyInPlaylist =>
      'Το τραγούδι είναι ήδη στη λίστα αναπαραγωγής';

  @override
  String get songRemoved => 'Το τραγούδι αφαιρέθηκε με επιτυχία!';

  @override
  String get songRemovedFromOffline =>
      'Το τραγούδι δεν είναι πλέον διαθέσιμο εκτός σύνδεσης';

  @override
  String get songs => 'Τραγούδια';

  @override
  String get sponsorBlockDescription =>
      'Παράλειψη διαφημιστικών τμημάτων σε υποστηριζόμενα κομμάτια.';

  @override
  String get sponsorProject => 'Χορηγία στον ιδιοκτήτη';

  @override
  String get suggestedArtists => 'Προτεινόμενοι καλλιτέχνες';

  @override
  String get suggestedPlaylists => 'Προτεινόμενες λίστες αναπαραγωγής';

  @override
  String get tapToView => 'Πατήστε για προβολή';

  @override
  String get themeMode => 'Λειτουργία θέματος';

  @override
  String get themeModeDark => 'Σκοτεινό';

  @override
  String get themeModeLight => 'Φωτεινό';

  @override
  String get themeModeSystem => 'Σύστημα';

  @override
  String get timeMachine => 'Time Machine';

  @override
  String get tools => 'Εργαλεία';

  @override
  String get topSongs => 'Top songs';

  @override
  String get translate => 'Μετάφραση';

  @override
  String get translateDescription =>
      'Βοήθα να μεταφραστεί η εφαρμογή στη δική σου γλώσσα στο Crowdin.';

  @override
  String get understand => 'Το κατάλαβα';

  @override
  String get undo => 'Αναίρεση';

  @override
  String get unpinFromLibrary => 'Unpin from library';

  @override
  String get update => 'Ενημέρωση';

  @override
  String get useProxy => 'Χρήση διαμεσολαβητή';

  @override
  String get useProxyDescription =>
      'Use the proxy only when streaming fails, unnecessary use may break playback.';

  @override
  String get userPlaylists => 'Λίστες αναπαραγωγής χρήστη';

  @override
  String get yes => 'Ναι';

  @override
  String get youtubePlaylistLinkOrId => 'YouTube playlist link or ID ';
}
