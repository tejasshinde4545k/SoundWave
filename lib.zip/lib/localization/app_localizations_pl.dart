// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Polish (`pl`).
class AppLocalizationsPl extends AppLocalizations {
  AppLocalizationsPl([String locale = 'pl']) : super(locale);

  @override
  String get about => 'O nas';

  @override
  String get accentChangeMsg => 'Zmieniono kolor akcentu';

  @override
  String get accentColor => 'Kolor akcentu';

  @override
  String get add => 'Dodaj';

  @override
  String get addPlaylist => 'Dodaj do playlisty';

  @override
  String get addToLikedPlaylists => 'Dodaj do polubionych list odtwarzania';

  @override
  String get addToLikedSongs => 'Dodaj do lubionych utworów';

  @override
  String get addToPlaylist => 'Dodaj do playlisty';

  @override
  String get addToQueue => 'Dodaj do kolejki';

  @override
  String get addedPlaylists => 'Dodano playlisty';

  @override
  String get addedSuccess => 'Pomyślnie dodano';

  @override
  String get addedToLikedSongs => 'Dodano do polubionych';

  @override
  String get album => 'Album';

  @override
  String get albums => 'Albumy';

  @override
  String get allSongs => 'All songs';

  @override
  String get alreadyDownloading => 'Już pobierane';

  @override
  String get annualRecap => 'Annual recap';

  @override
  String get appUpdateIsAvailable => 'Aktualizacja aplikacji jest dostępna';

  @override
  String get artist => 'Wykonawca';

  @override
  String get artistNotFound => 'Artist not found. Check logs or try again.';

  @override
  String get artists => 'Artists';

  @override
  String get audioQuality => 'Jakość dźwięku';

  @override
  String get audioQualityBadge => 'Show audio quality badge';

  @override
  String get audioQualityBadgeDescription =>
      'Display a small bitrate/codec badge on the now playing artwork.';

  @override
  String get audioQualityHigh => 'Wysoka';

  @override
  String get audioQualityLow => 'Niski';

  @override
  String get audioQualityMedium => 'Średni';

  @override
  String get audioQualityMsg => 'Jakość dźwięku została zmieniona';

  @override
  String get automaticSongPicker => 'Automatyczny wybór piosenek';

  @override
  String get automaticSongPickerDescription =>
      'Automatycznie graj następną piosenkę po obecnej.';

  @override
  String get automaticUpdateChecks => 'Automatyczne sprawdzanie aktualizacji';

  @override
  String get automaticUpdateChecksDescription =>
      'Automatycznie sprawdzaj dostępność aktualizacji aplikacji przy starcie.';

  @override
  String get back => 'Back';

  @override
  String get backToFavorites => 'Powrót do ulubionych';

  @override
  String get backedupSuccess => 'Utworzono kopię zapasową pomyślnie';

  @override
  String get backupError => 'Wystąpił błąd podczas tworzenia kopii zapasowej';

  @override
  String get backupUserData => 'Kopia zapasowa danych użytkownika';

  @override
  String get becomeSponsor => 'Zostań sponsorem';

  @override
  String get cacheMsg => 'Pamięć wyczyszczona';

  @override
  String get cancel => 'Anuluj';

  @override
  String get cancellingDownload => 'Cancelling download...';

  @override
  String get checkForUpdates => 'Sprawdzić aktualizacje?';

  @override
  String get chooseBackupDir => 'Wybierz ścieżkę do kopii zapasowej';

  @override
  String get chooseBackupFiles => 'Wybierz pliki do kopii zapasowej';

  @override
  String get clear => 'Wyczyść';

  @override
  String get clearCache => 'Wyczyść pamięć podręczną';

  @override
  String get clearListeningStats => 'Clear listening stats';

  @override
  String get clearListeningStatsQuestion =>
      'This will delete Time Machine listening stats stored on this device. Continue?';

  @override
  String get clearQueue => 'Wyczyść kolejkę';

  @override
  String get clearQueueQuestion => 'Are you sure you want to clear the queue?';

  @override
  String get clearRecentlyPlayed =>
      'Wyczyść historię ostatnio odtworzonych utworów';

  @override
  String get clearRecentlyPlayedQuestion =>
      'Wyczyścić historię ostatnio odtworzonych utworów?';

  @override
  String get clearSearchHistory => 'Wyczyść historię wyszukiwania';

  @override
  String get clearSearchHistoryQuestion => 'Wyczyścić historię wyszukiwania?';

  @override
  String get copy => 'Copy';

  @override
  String get confirm => 'Potwierdź';

  @override
  String get confirmation => 'Potwierdzenie';

  @override
  String get copyLogs => 'Kopiuj logi';

  @override
  String get copyLogsNoLogs => 'Brak logów do skopiowania';

  @override
  String get copyLogsSuccess => 'Pomyślnie skopiowano logi.';

  @override
  String get create => 'Utwórz';

  @override
  String get createFolder => 'Utwórz folder';

  @override
  String get custom => 'Niestandardowe';

  @override
  String get customPlaylistImgUrl => 'Własny link do okładki playlisty';

  @override
  String get customPlaylistName => 'Własna nazwa playlisty';

  @override
  String get customPlaylists => 'Niestandardowe listy odtwarzania';

  @override
  String get dateAdded => 'Data dodania';

  @override
  String get default_ => 'Domyślny';

  @override
  String get delete => 'Usuń';

  @override
  String get deleteDownloads => 'Delete downloads';

  @override
  String get deleteDownloadsQuestion =>
      'Are you sure you want to delete all downloads?';

  @override
  String get deleteFolder => 'Usuń folder';

  @override
  String get deleteFolderQuestion =>
      'Czy na pewno chcesz usunąć ten folder? Listy odtwarzania zostaną przeniesione do głównej biblioteki.';

  @override
  String get deletePlaylist => 'Usuń listę odtwarzania';

  @override
  String get download => 'Pobierz';

  @override
  String get downloadAppUpdate => 'Pobierz aktualizację aplikacji';

  @override
  String get downloadCancelled => 'Pobieranie anulowane';

  @override
  String get downloadFailed => 'Pobieranie nie powiodło się';

  @override
  String get downloadPlaylist => 'Pobierz playlistę';

  @override
  String get downloadsDeleted => 'Downloads deleted successfully';

  @override
  String get dynamicColor => 'Dynamiczny kolor akcentu (Android 12+)';

  @override
  String get dynamicColorDescription =>
      'Use the accent colors from your Android system theme.';

  @override
  String get editFolder => 'Edit folder';

  @override
  String get editPlaylist => 'Edytuj Playlistę';

  @override
  String get emptyFolderMsg =>
      'Ten folder jest pusty. Dodaj playlisty do organizacji muzyki.';

  @override
  String get enableUpdateChecksDescription =>
      'Czy chciałbyś, aby SoundWave automatycznie sprawdzała aktualizacje z wersji GitHub? Zawsze możesz sprawdzić dostępność aktualizacji ręcznie w ustawieniach';

  @override
  String get endOfSong => 'Koniec utworu';

  @override
  String get enterFolderName => 'Wprowadź nazwę folderu';

  @override
  String get equalizer => 'Equalizer';

  @override
  String get equalizerAndroidOnly => 'Equalizer is available on Android only.';

  @override
  String get equalizerBands => 'Bands';

  @override
  String get equalizerDisabledHint => 'Band gain adjustments are bypassed.';

  @override
  String get equalizerEnable => 'Enable equalizer';

  @override
  String get equalizerEnabledHint => 'Band gain adjustments are active.';

  @override
  String get equalizerInitFailed =>
      'Equalizer could not be initialized right now. Try playing a song and reopen this page.';

  @override
  String get equalizerPresetBalanced => 'Balanced';

  @override
  String get equalizerPresetBassBoost => 'Bass Boost';

  @override
  String get equalizerPresetElectronic => 'Electronic';

  @override
  String get equalizerPresetPop => 'Pop';

  @override
  String get equalizerPresetRock => 'Rock';

  @override
  String get equalizerPresetTrebleBoost => 'Treble Boost';

  @override
  String get equalizerPresetVocal => 'Vocal';

  @override
  String get equalizerPresets => 'Presets';

  @override
  String get equalizerResetBands => 'Reset bands';

  @override
  String get error => 'Coś poszło nie tak';

  @override
  String get externalRecommendations => 'Zewnętrzne rekomendacje';

  @override
  String get externalRecommendationsDescription =>
      'Używaj zewnętrznego algorytmu rekomendującego zamiast algorytmu od SoundWave.';

  @override
  String get failedPlayingRadio => 'Failed to play radio station';

  @override
  String get failedToLoadPlaylist => 'Failed to load playlist';

  @override
  String get fieldsNotEmpty => 'Wszystkie pola muszą być wypełnione';

  @override
  String get folderAlreadyExists => 'Folder o tej nazwie już istnieje';

  @override
  String get folderDeleted => 'Folder usunięty pomyślnie';

  @override
  String get folderName => 'Nazwa folderu';

  @override
  String get folderUpdated => 'Folder updated successfully';

  @override
  String get goToArtist => 'Go to artist';

  @override
  String get home => 'Dom';

  @override
  String get hours => 'Godziny';

  @override
  String get imagePicked => 'Wybrano obraz';

  @override
  String get importSpotifyPlaylist => 'Import playlist from Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Import Spotify playlist';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Export your Spotify playlist as CSV at chosic.com/spotify-playlist-exporter/, then choose the file or paste its contents below. SoundWave will search YouTube for each song.';

  @override
  String get chooseCsvFile => 'Choose CSV file';

  @override
  String get openChosicExporter => 'Open Chosic Spotify exporter';

  @override
  String get pasteCsv => 'Paste CSV';

  @override
  String get playlistName => 'Playlist name';

  @override
  String get importPlaylist => 'Import playlist';

  @override
  String get spotifyCsvHint => 'Paste CSV content here';

  @override
  String get spotifyPlaylistNameHint => 'Imported Spotify playlist';

  @override
  String get spotifyPlaylistEmpty =>
      'Choose a CSV file or paste CSV content first';

  @override
  String get enterPlaylistName => 'Please enter a playlist name';

  @override
  String get spotifyPlaylistInvalid =>
      'The CSV does not contain Song and Artist columns';

  @override
  String get spotifyPlaylistImporting => 'Importing playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found of $total songs imported';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Searching $done of $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'An import is already in progress';

  @override
  String get spotifyPlaylistMissingSongs => 'Songs not found';

  @override
  String get spotifyPlaylistImportFailed => 'Playlist import failed';

  @override
  String get invalidYouTubePlaylist => 'Nieprawidłowa playlista Youtube';

  @override
  String get language => 'Język';

  @override
  String get languageDe => 'German';

  @override
  String get languageEl => 'Greek';

  @override
  String get languageEn => 'English';

  @override
  String get languageEs => 'Spanish';

  @override
  String get languageEt => 'Estonian';

  @override
  String get languageFr => 'French';

  @override
  String get languageHe => 'Hebrew';

  @override
  String get languageHi => 'Hindi';

  @override
  String get languageHu => 'Hungarian';

  @override
  String get languageId => 'Indonesian';

  @override
  String get languageIt => 'Italian';

  @override
  String get languageJa => 'Japanese';

  @override
  String get languageKo => 'Korean';

  @override
  String get languageMsg => 'Język został zmieniony';

  @override
  String get languagePl => 'Polish';

  @override
  String get languagePt => 'Portuguese';

  @override
  String get languageRu => 'Russian';

  @override
  String get languageSv => 'Swedish';

  @override
  String get languageTa => 'Tamil';

  @override
  String get languageTr => 'Turkish';

  @override
  String get languageUk => 'Ukrainian';

  @override
  String get languageZh => 'Chinese (Simplified)';

  @override
  String get languageZhHant => 'Chinese (Traditional)';

  @override
  String get library => 'Biblioteka';

  @override
  String get licenses => 'Licencje';

  @override
  String get likedPlaylists => 'Polubione playlisty';

  @override
  String get likedSongs => 'Polubione utwory';

  @override
  String get linkCopied => 'Playlist link copied to clipboard';

  @override
  String get listeningStats => 'Listening stats';

  @override
  String get listeningStatsCleared => 'Listening stats cleared';

  @override
  String get listeningStatsDescription =>
      'Track local listening stats for monthly and yearly recaps.';

  @override
  String get loading => 'Loading';

  @override
  String get lyrics => 'Teksty';

  @override
  String get lyricsNotAvailable => 'Brak dostępnych tekstów';

  @override
  String get makeOffline => 'Udostępnij offline';

  @override
  String get minutes => 'Protokoły';

  @override
  String get minutesListened => 'minutes listened';

  @override
  String get monthlyListeners => 'monthly listeners';

  @override
  String get moreOptions => 'More options';

  @override
  String get mostPlayed => 'Most played';

  @override
  String get moveToFolder => 'Przenieś do katalogu';

  @override
  String get name => 'Nazwa';

  @override
  String get newAnnouncement => 'Nowe ogłoszenie opublikowane';

  @override
  String get newFolder => 'Nowy folder';

  @override
  String get no => 'Nie';

  @override
  String get noCustomPlaylists => 'Nie masz żadnej własnej playlisty';

  @override
  String get noFolders => 'No folders created yet';

  @override
  String get noListeningStats => 'No listening stats yet';

  @override
  String get noOfflineLibraryContent =>
      'Brak treści offline. Włącz tryb online lub pobierz playlisty/utwory, aby użyć biblioteki.';

  @override
  String get noPlaylistsAdded => 'Nie dodano jeszcze list odtwarzania';

  @override
  String get noRadioStations => 'No radio stations available';

  @override
  String get noSongsInPlaylist => 'No songs in playlist';

  @override
  String get noSongsInQueue => 'Brak utworów w kolejce';

  @override
  String get notYTlist => 'To nie jest ID playlisty w YouTube';

  @override
  String get offlineMode => 'Tryb offline';

  @override
  String get offlineModeDescription =>
      'Wyłącz funkcje online i używaj SoundWave całkowicie offline.';

  @override
  String get offlinePlaylists => 'Listy odtwarzania offline';

  @override
  String get offlineSongs => 'Utwory offline';

  @override
  String get others => 'Inne';

  @override
  String get pause => 'Pause';

  @override
  String get pickImageFromDevice => 'Wybierz obraz z urządzenia';

  @override
  String get pinToLibrary => 'Pin to library';

  @override
  String get pinnedPlaylists => 'Pinned';

  @override
  String get pinnedPlaylistsLimit => 'You can pin up to 5 playlists or albums';

  @override
  String get play => 'Play';

  @override
  String get playNext => 'Odtwórz następne';

  @override
  String get playlist => 'Playlista';

  @override
  String get playlistAlreadyDownloaded => 'Lista odtwarzania jest już pobrana';

  @override
  String get playlistAlreadyExists => 'Playlista już istnieje';

  @override
  String get playlistDownloaded => 'Lista odtwarzania pobrana';

  @override
  String get playlistEmpty => 'Lista odtwarzania jest pusta';

  @override
  String get playlistFolders => 'Foldery listy odtwarzania';

  @override
  String get playlistRemovedFromOffline =>
      'Lista odtwarzania usunięta z pamięci offline';

  @override
  String get playlistUpdated => 'Playlista zaktualizowana pomyślnie';

  @override
  String get playlists => 'Playlisty';

  @override
  String get preferences => 'Preferencje';

  @override
  String get provideIdOrNameError =>
      'Podaj ID YouTube lub własną nazwę playlisty';

  @override
  String get pureBlackTheme => 'Motyw czarny';

  @override
  String get pureBlackThemeDescription =>
      'Use a true black background in dark mode for OLED displays.';

  @override
  String get queue => 'Kolejka';

  @override
  String get radioStations => 'Radio Stations';

  @override
  String get recentlyPlayed => 'Ostatnio odtwarzane';

  @override
  String get recentlyPlayedMsg =>
      'Wyczyszczono historię ostatnio odtworzonych utworów';

  @override
  String get recommendedForYou => 'Polecane dla Ciebie';

  @override
  String get remove => 'Usuń';

  @override
  String get removeFromFolder => 'Usuń z folderu';

  @override
  String get removeFromLikedPlaylists => 'Usuń z polubionych list odtwarzania';

  @override
  String get removeFromLikedSongs => 'Usuń z polubionych utworów';

  @override
  String get removeFromPlaylist => 'Usuń z listy odtwarzania';

  @override
  String get removeFromRecentlyPlayed => 'Usuń z ostatnio odtwarzanych';

  @override
  String get removeOffline => 'Usuń z trybu offline';

  @override
  String get removeOfflinePlaylist => 'Usuń listę odtwarzania offline';

  @override
  String get removeOfflinePlaylistConfirm =>
      'Spowoduje to usunięcie listy odtwarzania z pamięci offline. Utwory używane w innych playlistach będą nadal dostępne.';

  @override
  String get removePlaylistQuestion => 'Usunąć tą playlistę?';

  @override
  String get removeSearchQueryQuestion => 'Usunąć to wyszukiwanie?';

  @override
  String get removedFromLikedSongs => 'Usunięto z polubionych utworów';

  @override
  String get renameSong => 'Zmień nazwę utworu';

  @override
  String get repeat => 'Repeat';

  @override
  String get replay => 'Replay';

  @override
  String get restoreError => 'Błąd podczas przywracania danych';

  @override
  String get restoreUserData => 'Przywróć dane użytkownika';

  @override
  String get restoredSuccess => 'Przywrócono pomyślnie';

  @override
  String get search => 'Szukaj';

  @override
  String get searchHistoryMsg => 'Historia wyszukiwania wyczyszczona';

  @override
  String get selectDuration => 'Wybierz czas trwania';

  @override
  String get setTimer => 'Ustaw minutnik';

  @override
  String get settingChangedMsg => 'Ustawienie zostało zmienione';

  @override
  String get settings => 'Ustawienia';

  @override
  String get share => 'Share';

  @override
  String get shareRecap => 'Share recap';

  @override
  String get shareTimeMachineText => 'My SoundWave recap';

  @override
  String get shuffle => 'Shuffle';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Singles & EPs';

  @override
  String get skipToNext => 'Skip to next';

  @override
  String get skipToPrevious => 'Skip to previous';

  @override
  String get sleepTimer => 'Sleep timer';

  @override
  String get sleepTimerCancelled => 'Wyłącznik czasowy został anulowany';

  @override
  String get sleepTimerSet => 'Czas uśpienia ustawiony';

  @override
  String get songAdded => 'Utwór pomyślnie dodany!';

  @override
  String get songAddedToOffline => 'Utwór jest teraz dostępny w trybie offline';

  @override
  String get songAlreadyInPlaylist => 'Utwór jest już na liście odtwarzania';

  @override
  String get songRemoved => 'Utwór pomyślnie usunięty!';

  @override
  String get songRemovedFromOffline =>
      'Utwór nie jest już dostępny w trybie offline';

  @override
  String get songs => 'Utwory';

  @override
  String get sponsorBlockDescription =>
      'Pomiń sponsorowane segmenty w obsługiwanych utworach.';

  @override
  String get sponsorProject => 'Sponsorowanie projektu';

  @override
  String get suggestedArtists => 'Sugerowani artyści';

  @override
  String get suggestedPlaylists => 'Sugerowane playlisty';

  @override
  String get tapToView => 'Stuknij, aby zobaczyć';

  @override
  String get themeMode => 'Motyw';

  @override
  String get themeModeDark => 'Ciemny';

  @override
  String get themeModeLight => 'Światło';

  @override
  String get themeModeSystem => 'System';

  @override
  String get timeMachine => 'Time Machine';

  @override
  String get tools => 'Narzędzia';

  @override
  String get topSongs => 'Top songs';

  @override
  String get translate => 'Przetłumacz SoundWave';

  @override
  String get translateDescription =>
      'Pomóż przetłumaczyć SoundWave na Twój język na Crowdin.';

  @override
  String get understand => 'Rozumiem';

  @override
  String get undo => 'Cofnij';

  @override
  String get unpinFromLibrary => 'Unpin from library';

  @override
  String get update => 'Aktualizuj';

  @override
  String get useProxy => 'Użyj proxy';

  @override
  String get useProxyDescription =>
      'Używaj proxy tylko wtedy, gdy strumieniowanie nie powiedzie się, niepotrzebne użycie może uszkodzić odtwarzanie.';

  @override
  String get userPlaylists => 'Playlisty użytkownika';

  @override
  String get yes => 'Tak';

  @override
  String get youtubePlaylistLinkOrId => 'Link lub ID playlisty YouTube';
}
