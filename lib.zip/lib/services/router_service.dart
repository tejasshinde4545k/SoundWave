/*
 *     Copyright (C) 2026 Valeri Gokadze
 *
 *     SoundWave is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     SoundWave is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 *
 *     For more information about SoundWave, including how to contribute,
 *     please visit: https://github.com/tejasshinde4545k/SoundWave
 */

import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/foundation.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:soundwave/constants/version.dart';
import 'package:soundwave/screens/about_page.dart';
import 'package:soundwave/screens/artist_page.dart';
import 'package:soundwave/screens/best_artists_page.dart';
import 'package:soundwave/screens/bottom_navigation_page.dart';
import 'package:soundwave/screens/equalizer_page.dart';
import 'package:soundwave/screens/home_page.dart';
import 'package:soundwave/screens/import_spotify_playlist_page.dart';
import 'package:soundwave/screens/library_page.dart';
import 'package:soundwave/screens/playlist_folder_page.dart';
import 'package:soundwave/screens/playlist_page.dart';
import 'package:soundwave/screens/radio_stations_page.dart';
import 'package:soundwave/screens/released_this_week_page.dart';
import 'package:soundwave/screens/search_page.dart';
import 'package:soundwave/screens/settings_page.dart';
import 'package:soundwave/screens/splash_page.dart';
import 'package:soundwave/screens/time_machine_page.dart';
import 'package:soundwave/screens/user_songs_page.dart';
import 'package:soundwave/services/playlist_download_service.dart';
import 'package:soundwave/services/settings_manager.dart';
import 'package:soundwave/widgets/offline_search_placeholder.dart';

class NavigationManager {
  factory NavigationManager() {
    return _instance;
  }

  NavigationManager._internal() {
    _setupRouter();
  }

  void _setupRouter() {
    final routes = [
      GoRoute(
        path: splashPath,
        parentNavigatorKey: parentNavigatorKey,
        pageBuilder: (context, state) {
          return getPage(
            child: const SplashPage(),
            state: state,
          );
        },
      ),
      StatefulShellRoute.indexedStack(
        parentNavigatorKey: parentNavigatorKey,
        branches: _getRouteBranches(),
        pageBuilder: (context, state, navigationShell) {
          return getPage(
            child: BottomNavigationPage(child: navigationShell),
            state: state,
          );
        },
      ),
    ];

    router = GoRouter(
      navigatorKey: parentNavigatorKey,
      initialLocation: splashPath,
      routes: routes,
      restorationScopeId: 'router',
      debugLogDiagnostics: kDebugMode,
      routerNeglect: true,
      redirect: (context, state) {
        final currentPath = state.matchedLocation;
        if (currentPath == splashPath) {
          return null;
        }

        // Handle offline mode redirects
        final isOffline = offlineMode.value;

        if (isOffline &&
            (currentPath == searchPath ||
                currentPath == timeMachinePath ||
                currentPath == releasedThisWeekPath ||
                currentPath == bestArtistsPath)) {
          // Redirect unavailable pages to home in offline mode
          return homePath;
        }

        if (isOffline && currentPath.contains('/album/')) {
          // Releases are only browsable through YouTube Music.
          return homePath;
        }

        if (isOffline && currentPath.contains('/artist/')) {
          final artistId = _decodePathParameter(
            state.pathParameters['artistId'],
          );
          if (!offlinePlaylistService.isPlaylistDownloaded(artistId)) {
            return homePath;
          }
        }

        return null; // No redirect needed
      },
    );
  }

  static final NavigationManager _instance = NavigationManager._internal();

  static NavigationManager get instance => _instance;

  static late final GoRouter router;

  static final GlobalKey<NavigatorState> parentNavigatorKey =
      GlobalKey<NavigatorState>();
  static final GlobalKey<NavigatorState> homeTabNavigatorKey =
      GlobalKey<NavigatorState>();
  static final GlobalKey<NavigatorState> searchTabNavigatorKey =
      GlobalKey<NavigatorState>();
  static final GlobalKey<NavigatorState> libraryTabNavigatorKey =
      GlobalKey<NavigatorState>();
  static final GlobalKey<NavigatorState> settingsTabNavigatorKey =
      GlobalKey<NavigatorState>();

  BuildContext get context {
    final ctx = router.routerDelegate.navigatorKey.currentContext;
    if (ctx == null) {
      throw StateError(
        'NavigationManager.context was accessed before the navigator context was available.',
      );
    }
    return ctx;
  }

  GoRouterDelegate get routerDelegate => router.routerDelegate;

  GoRouteInformationParser get routeInformationParser =>
      router.routeInformationParser;

  static const String splashPath = '/splash';
  static const String homePath = '/home';
  static const String timeMachinePath = '$homePath/timeMachine';
  static const String releasedThisWeekPath = '$homePath/releasedThisWeek';
  static const String bestArtistsPath = '$homePath/bestArtists';
  static const String settingsPath = '/settings';
  static const String searchPath = '/search';
  static const String libraryPath = '/library';

  /// Refresh the router configuration when offline mode changes
  static void refreshRouter() {
    // Force router to re-evaluate redirect logic
    router.refresh();
  }

  List<StatefulShellBranch> _getRouteBranches() {
    // Always return all branches, but handle visibility in the UI
    return [
      // Branch 0: Home
      StatefulShellBranch(
        navigatorKey: homeTabNavigatorKey,
        routes: [
          GoRoute(
            path: homePath,
            pageBuilder: (context, GoRouterState state) {
              return getPage(
                child: ValueListenableBuilder<bool>(
                  valueListenable: offlineMode,
                  builder: (context, isOffline, _) {
                    return isOffline
                        ? const UserSongsPage(page: 'offline')
                        : const HomePage();
                  },
                ),
                state: state,
              );
            },
            routes: [
              GoRoute(
                path: 'timeMachine',
                pageBuilder: (context, state) =>
                    _pushPage(child: const TimeMachinePage(), state: state),
              ),
              GoRoute(
                path: 'releasedThisWeek',
                pageBuilder: (context, state) {
                  final extraMap =
                      state.extra is Map ? state.extra as Map : null;
                  return _pushPage(
                    child: ReleasedThisWeekPage(
                      initialSongs: extraMap?['songs'] as List?,
                      weekRangeText: extraMap?['weekRange']?.toString(),
                    ),
                    state: state,
                  );
                },
              ),
              GoRoute(
                path: 'bestArtists',
                pageBuilder: (context, state) {
                  final extraMap =
                      state.extra is Map ? state.extra as Map : null;
                  return _pushPage(
                    child: BestArtistsPage(
                      initialArtists: (extraMap?['artists'] as List?)
                          ?.map((e) => Map<String, dynamic>.from(e as Map))
                          .toList(),
                    ),
                    state: state,
                  );
                },
              ),
              GoRoute(
                path: 'library',
                pageBuilder: (context, state) =>
                    _pushPage(child: const LibraryPage(), state: state),
              ),
              GoRoute(
                path: 'playlist/:playlistId',
                pageBuilder: (context, state) => _pushPage(
                  child: PlaylistPage(
                    playlistId: _decodePathParameter(
                      state.pathParameters['playlistId'],
                    ),
                    playlistData: _extraAsMap(state.extra),
                  ),
                  state: state,
                ),
              ),
              _artistRoute(),
              _albumRoute(),
              GoRoute(
                path: 'folder/:folderId/:folderName',
                pageBuilder: (context, state) => _pushPage(
                  child: PlaylistFolderPage(
                    folderId: state.pathParameters['folderId'] ?? '',
                    folderName: state.pathParameters['folderName'] ?? '',
                  ),
                  state: state,
                ),
              ),
            ],
          ),
        ],
      ),
      // Branch 1: Search
      StatefulShellBranch(
        navigatorKey: searchTabNavigatorKey,
        routes: [
          GoRoute(
            path: searchPath,
            pageBuilder: (context, GoRouterState state) {
              return getPage(
                child: ValueListenableBuilder<bool>(
                  valueListenable: offlineMode,
                  builder: (context, isOffline, _) {
                    return isOffline
                        ? const OfflineSearchPlaceholder()
                        : const SearchPage();
                  },
                ),
                state: state,
              );
            },
            routes: [_artistRoute(), _albumRoute()],
          ),
        ],
      ),
      // Branch 2: Library
      StatefulShellBranch(
        navigatorKey: libraryTabNavigatorKey,
        routes: [
          GoRoute(
            path: libraryPath,
            pageBuilder: (context, GoRouterState state) {
              return getPage(child: const LibraryPage(), state: state);
            },
            routes: [
              GoRoute(
                path: 'userSongs/:page',
                pageBuilder: (context, state) => _pushPage(
                  child: UserSongsPage(
                    page: state.pathParameters['page'] ?? 'liked',
                  ),
                  state: state,
                ),
              ),
              _artistRoute(),
              _albumRoute(),
              GoRoute(
                path: 'radioStations',
                pageBuilder: (context, state) =>
                    _pushPage(child: const RadioStationsPage(), state: state),
              ),
            ],
          ),
        ],
      ),
      // Branch 3: Settings
      StatefulShellBranch(
        navigatorKey: settingsTabNavigatorKey,
        routes: [
          GoRoute(
            path: settingsPath,
            pageBuilder: (context, state) {
              return getPage(child: const SettingsPage(), state: state);
            },
            routes: [
              GoRoute(
                path: 'license',
                pageBuilder: (context, state) => _pushPage(
                  child: const LicensePage(
                    applicationName: 'SoundWave',
                    applicationVersion: appVersion,
                  ),
                  state: state,
                ),
              ),
              GoRoute(
                path: 'about',
                pageBuilder: (context, state) =>
                    _pushPage(child: const AboutPage(), state: state),
              ),
              GoRoute(
                path: 'equalizer',
                pageBuilder: (context, state) =>
                    _pushPage(child: const EqualizerPage(), state: state),
              ),
              GoRoute(
                path: 'import-spotify-playlist',
                pageBuilder: (context, state) => _pushPage(
                  child: const ImportSpotifyPlaylistPage(),
                  state: state,
                ),
              ),
            ],
          ),
        ],
      ),
    ];
  }

  /// The artist landing page, plus the full song catalog of the artist.
  GoRoute _artistRoute() {
    return GoRoute(
      path: 'artist/:artistId',
      pageBuilder: (context, state) => _pushPage(
        child: ArtistPage(
          artistId: _decodePathParameter(state.pathParameters['artistId']),
          artistData: _extraAsMap(state.extra),
        ),
        state: state,
      ),
      routes: [
        GoRoute(
          path: 'songs',
          pageBuilder: (context, state) => _pushPage(
            child: PlaylistPage(
              playlistId: _decodePathParameter(
                state.pathParameters['artistId'],
              ),
              playlistData: _extraAsMap(state.extra),
              cubeIcon: FluentIcons.person_24_filled,
              isArtist: true,
            ),
            state: state,
          ),
        ),
      ],
    );
  }

  /// A release opened from an artist page. YouTube Music browses a release the
  /// way it browses a playlist, so the playlist page shows it as it is.
  GoRoute _albumRoute() {
    return GoRoute(
      path: 'album/:albumId',
      pageBuilder: (context, state) => _pushPage(
        child: PlaylistPage(
          playlistId: _decodePathParameter(state.pathParameters['albumId']),
          playlistData: _extraAsMap(state.extra),
          cubeIcon: FluentIcons.cd_16_regular,
        ),
        state: state,
      ),
    );
  }

  /// Path of the page of an artist, inside the tab [context] belongs to.
  static String artistPath(BuildContext context, String artistId) =>
      '${basePathFor(context)}/artist/${Uri.encodeComponent(artistId)}';

  /// Path of the songs of an artist, i.e. of its "All songs" playlist.
  static String artistSongsPath(BuildContext context, String artistId) =>
      '${artistPath(context, artistId)}/songs';

  /// Path of the page of a YouTube Music release.
  static String albumPath(BuildContext context, String albumId) =>
      '${basePathFor(context)}/album/${Uri.encodeComponent(albumId)}';

  /// Path of the playlist page, inside the tab [context] belongs to.
  static String playlistPath(BuildContext context, String playlistId) =>
      '${basePathFor(context)}/playlist/${Uri.encodeComponent(playlistId)}';

  /// The tab a sub page pushed from [context] belongs to, so that artists,
  /// albums and playlists stay inside the tab they were opened from.
  static String basePathFor(BuildContext context) {
    try {
      final currentPath = GoRouterState.of(context).uri.path;
      if (currentPath.startsWith(searchPath)) return searchPath;
      if (currentPath.startsWith(libraryPath)) return libraryPath;
    } catch (_) {}

    return homePath;
  }

  static String _decodePathParameter(String? value) {
    if (value == null || value.isEmpty) return '';
    return Uri.decodeComponent(value);
  }

  static Map? _extraAsMap(Object? extra) {
    if (extra is Map) return Map<String, dynamic>.from(extra);
    return null;
  }

  static Page<void> getPage({
    required Widget child,
    required GoRouterState state,
  }) {
    return CustomTransitionPage<void>(
      key: state.pageKey,
      child: child,
      transitionDuration: const Duration(milliseconds: 180),
      reverseTransitionDuration: const Duration(milliseconds: 150),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(
          opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
          child: child,
        );
      },
    );
  }

  static Page<void> _pushPage({
    required Widget child,
    required GoRouterState state,
  }) {
    return CustomTransitionPage<void>(
      key: state.pageKey,
      child: child,
      transitionDuration: const Duration(milliseconds: 220),
      reverseTransitionDuration: const Duration(milliseconds: 180),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        final curvedAnimation = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return FadeTransition(
          opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.06, 0),
              end: Offset.zero,
            ).animate(curvedAnimation),
            child: child,
          ),
        );
      },
    );
  }
}
